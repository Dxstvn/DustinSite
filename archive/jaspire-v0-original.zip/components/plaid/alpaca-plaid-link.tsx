"use client"

import { useState, useCallback } from "react"
import { usePlaidLink } from "react-plaid-link"
import { Button } from "@/components/ui/button"
import { Loader2 } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

interface AlpacaPlaidLinkProps {
  alpacaAccountId: string
  onSuccess?: () => void
  onExit?: () => void
  className?: string
  buttonText?: string
  variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link"
}

export function AlpacaPlaidLink({
  alpacaAccountId,
  onSuccess,
  onExit,
  className,
  buttonText = "Link Your Bank Account",
  variant = "default",
}: AlpacaPlaidLinkProps) {
  const [linkToken, setLinkToken] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const fetchLinkToken = useCallback(async () => {
    try {
      setIsLoading(true)
      // Request a link token specifically for Alpaca integration
      const response = await fetch("/api/plaid/create-alpaca-link-token", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ alpacaAccountId }),
      })

      if (!response.ok) {
        throw new Error("Failed to create link token for Alpaca")
      }

      const data = await response.json()
      setLinkToken(data.link_token)
    } catch (error) {
      console.error("Error creating Alpaca link token:", error)
      toast({
        title: "Connection Error",
        description: "Unable to initialize bank connection. Please try again later.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }, [alpacaAccountId])

  // Handle successful Plaid Link completion
  const handleSuccess = useCallback(
    async (publicToken: string, metadata: any) => {
      try {
        setIsLoading(true)
        // Exchange the public token and link it to the Alpaca account
        const response = await fetch("/api/plaid/exchange-alpaca-token", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            publicToken,
            metadata,
            alpacaAccountId,
          }),
        })

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || "Failed to link bank account")
        }

        toast({
          title: "Success!",
          description: "Your bank account has been successfully linked to your investment account.",
        })

        // Call the onSuccess callback if provided
        if (onSuccess) {
          onSuccess()
        } else {
          // Default behavior: redirect to dashboard
          router.push("/dashboard?bankLinked=true")
        }
      } catch (error) {
        console.error("Error exchanging token for Alpaca:", error)
        toast({
          title: "Connection Failed",
          description: "We couldn't link your bank account. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    },
    [alpacaAccountId, onSuccess, router],
  )

  // Initialize Plaid Link
  const { open, ready } = usePlaidLink({
    token: linkToken,
    onSuccess: handleSuccess,
    onExit: () => {
      if (onExit) {
        onExit()
      }
    },
  })

  // Fetch the link token when the component mounts
  const handleClick = () => {
    if (linkToken && ready) {
      open()
    } else {
      fetchLinkToken()
        .then(() => {
          // After fetching the token, open Plaid Link if ready
          if (ready) {
            setTimeout(() => open(), 100)
          }
        })
        .catch((error) => {
          console.error("Error preparing Plaid Link:", error)
        })
    }
  }

  return (
    <Button onClick={handleClick} disabled={isLoading} className={className} variant={variant}>
      {isLoading ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Connecting...
        </>
      ) : (
        buttonText
      )}
    </Button>
  )
}
