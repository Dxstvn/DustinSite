import { NextResponse } from "next/server"
import { plaidApi } from "@/lib/plaid-api"

export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json()
    const { publicToken, metadata, alpacaAccountId } = body

    if (!publicToken) {
      return NextResponse.json({ error: "Public token is required" }, { status: 400 })
    }

    if (!alpacaAccountId) {
      return NextResponse.json({ error: "Alpaca account ID is required" }, { status: 400 })
    }

    // In a real implementation, you would verify the user is authenticated
    // const auth = getAuth()
    // if (!auth.currentUser) {
    //   return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    // }

    // Exchange the public token for an access token
    const accessToken = await plaidApi.exchangePublicToken(publicToken)

    if (!accessToken) {
      return NextResponse.json({ error: "Failed to exchange token" }, { status: 500 })
    }

    // In a real implementation, you would:
    // 1. Get the bank account details from Plaid using the access token
    // 2. Send those details to Alpaca to link the bank account to the investment account
    // 3. Store the relationship in your database

    // For demo purposes, we'll simulate a successful linking
    console.log(`Linked bank account to Alpaca account ${alpacaAccountId}`)
    console.log(`Selected account: ${metadata?.account?.id || "Unknown"}`)

    // Return success response
    return NextResponse.json({
      success: true,
      message: "Bank account successfully linked to investment account",
    })
  } catch (error) {
    console.error("Error exchanging token for Alpaca:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
