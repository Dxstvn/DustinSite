import { NextResponse } from "next/server"
import { plaidApi } from "@/lib/plaid-api"

export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json()
    const { alpacaAccountId } = body

    if (!alpacaAccountId) {
      return NextResponse.json({ error: "Alpaca account ID is required" }, { status: 400 })
    }

    // In a real implementation, you would verify the user is authenticated
    // and has access to this Alpaca account
    // const auth = getAuth()
    // if (!auth.currentUser) {
    //   return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    // }

    // For demo, use a mock user ID
    const userId = "demo_user_123"

    // Create a link token specifically for Alpaca integration
    // In a real implementation, you would pass the alpacaAccountId to the Plaid API
    const linkToken = await plaidApi.createLinkToken(userId, {
      // These would be the actual parameters for Alpaca integration
      clientName: "Jaspire Investments",
      language: "en",
      products: ["auth"],
      countryCodes: ["US"],
      webhook: "https://your-app-domain.com/api/plaid/webhook",
      accountSubtypes: {
        depository: ["checking", "savings"],
      },
    })

    if (!linkToken) {
      return NextResponse.json({ error: "Failed to create link token" }, { status: 500 })
    }

    return NextResponse.json({ link_token: linkToken })
  } catch (error) {
    console.error("Error creating Alpaca link token:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
