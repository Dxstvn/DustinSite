# Jaspire - Premium Web Development Agency

A cutting-edge web development agency website built with Next.js 14, TypeScript, and Tailwind CSS, featuring Apple-inspired animations and glassmorphism design.

## 🚀 Tech Stack

- **Framework:** Next.js 14 with App Router
- **Language:** TypeScript
- **Styling:** Tailwind CSS + Framer Motion
- **3D Graphics:** Three.js + React Three Fiber
- **State Management:** Zustand
- **Forms:** React Hook Form + Zod
- **Testing:** Vitest + Playwright
- **Deployment:** Vercel

## 📦 Installation

```bash
# Install dependencies
npm install --legacy-peer-deps

# Run development server
npm run dev

# Build for production
npm run build

# Run tests
npm run test
```

## 🎨 Design Principles

1. **Apple-Inspired Motion Design** - Smooth, purposeful animations with spring physics
2. **Bento Grid Architecture** - Modular, responsive layout system
3. **Glassmorphism** - Multi-layer transparency effects
4. **Dark Mode First** - Sophisticated dark theme
5. **Micro-interactions** - Delightful user feedback

## 🏗️ Project Structure

```
src/
├── app/              # Next.js app router pages
├── components/       # React components
│   ├── ui/          # Base UI components
│   ├── features/    # Feature components
│   └── animations/  # Animation components
├── lib/             # Utilities and hooks
│   ├── hooks/       # Custom React hooks
│   ├── stores/      # Zustand stores
│   └── utils/       # Helper functions
└── styles/          # Global styles
```

## 🧪 Testing

```bash
# Run unit tests
npm run test

# Run with coverage
npm run test:coverage

# Run E2E tests
npm run test:e2e
```

## 📝 Commit Convention

This project follows [Conventional Commits](https://www.conventionalcommits.org/):

- `feat:` New feature
- `fix:` Bug fix
- `docs:` Documentation
- `style:` Code style changes
- `refactor:` Code refactoring
- `perf:` Performance improvements
- `test:` Testing
- `chore:` Maintenance

## 🚀 Deployment

The site is automatically deployed to Vercel on push to main branch.

```bash
# Deploy preview
vercel

# Deploy to production
vercel --prod
```

## 🌐 Domain

Production: [jaspire.co](https://jaspire.co)

## 📄 License

© 2024 Jaspire. All rights reserved.
