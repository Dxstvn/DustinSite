/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: {
    // Disable ESLint during builds for bundle analysis
    ignoreDuringBuilds: true,
  },
  typescript: {
    // Continue build even with TypeScript errors for analysis
    ignoreBuildErrors: true,
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
    ],
    formats: ['image/avif', 'image/webp'],
    minimumCacheTTL: 60,
    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
  },
  experimental: {
    // Enable modern bundling features
    optimizePackageImports: [
      'framer-motion',
      'three',
      '@radix-ui/react-icons',
      'lucide-react'
    ],
  },
  // Optimize imports
  webpack: (config, { buildId, dev, isServer, defaultLoaders, webpack }) => {
    config.resolve.alias = {
      ...config.resolve.alias,
      // Tree-shake lodash
      'lodash': 'lodash-es',
    };

    return config;
  },
  // Compression and optimization
  compress: true,
  poweredByHeader: false,
  generateEtags: true,
  
  // Output configuration
  output: 'standalone',
  
  // Performance budgets
  onDemandEntries: {
    maxInactiveAge: 25 * 1000,
    pagesBufferLength: 2,
  },
};

export default nextConfig;