'use client';

import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/Button';
import { RefreshCw, Home, AlertTriangle, Mail } from 'lucide-react';
import Link from 'next/link';

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Log the error to an error reporting service
    console.error('Application error:', error);
  }, [error]);

  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-red-900/20 via-black to-orange-900/20" />
      
      {/* Grid pattern */}
      <div className="absolute inset-0 grid-bg opacity-[0.02]" />
      
      {/* Animated background orbs */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-red-500/10 rounded-full blur-3xl animate-pulse-slow" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl animate-pulse-slow" />
      
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-2xl mx-auto"
        >
          {/* Error Icon */}
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="mb-8 flex justify-center"
          >
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-red-500/20 to-orange-500/20 flex items-center justify-center glass">
              <AlertTriangle className="w-16 h-16 text-orange-400" />
            </div>
          </motion.div>
          
          {/* Error message */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="space-y-4 mb-12"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white">
              Something went wrong!
            </h1>
            <p className="text-lg text-gray-400 max-w-md mx-auto">
              We encountered an unexpected error. Our team has been notified and is working on a fix.
            </p>
            
            {/* Error details (only in development) */}
            {process.env.NODE_ENV === 'development' && error.message && (
              <div className="mt-6 p-4 bg-red-950/30 border border-red-900/30 rounded-lg text-left">
                <p className="text-xs text-red-400 font-mono break-all">
                  {error.message}
                </p>
                {error.digest && (
                  <p className="text-xs text-gray-500 mt-2">
                    Error ID: {error.digest}
                  </p>
                )}
              </div>
            )}
          </motion.div>
          
          {/* Action buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Button
              onClick={reset}
              variant="gradient"
              size="lg"
              className="btn-premium min-w-[160px]"
            >
              <RefreshCw className="mr-2 w-4 h-4" />
              Try Again
            </Button>
            
            <Link href="/">
              <Button
                variant="outline"
                size="lg"
                className="glass glass-hover min-w-[160px]"
              >
                <Home className="mr-2 w-4 h-4" />
                Go Home
              </Button>
            </Link>
          </motion.div>
          
          {/* Support link */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.6 }}
            className="mt-16 pt-8 border-t border-white/10"
          >
            <p className="text-sm text-gray-500 mb-4">Need help?</p>
            <a
              href="mailto:support@jaspire.com"
              className="inline-flex items-center text-blue-400 hover:text-blue-300 transition-colors text-sm"
            >
              <Mail className="mr-2 w-4 h-4" />
              Contact Support
            </a>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}