'use client';

import { Navigation } from '@/components/layouts/Navigation';
import { Footer } from '@/components/layouts/Footer';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Award, Users, Zap, Target, Heart, Shield } from 'lucide-react';

const values = [
  {
    icon: Target,
    title: 'Excellence',
    description: 'We strive for perfection in every line of code and pixel we craft.',
  },
  {
    icon: Users,
    title: 'Collaboration',
    description: 'Working closely with clients to understand and exceed their expectations.',
  },
  {
    icon: Zap,
    title: 'Innovation',
    description: 'Embracing cutting-edge technologies to deliver future-proof solutions.',
  },
  {
    icon: Shield,
    title: 'Integrity',
    description: 'Building trust through transparency, honesty, and reliable delivery.',
  },
  {
    icon: Heart,
    title: 'Passion',
    description: 'Loving what we do and putting our heart into every project.',
  },
  {
    icon: Award,
    title: 'Quality',
    description: 'Maintaining the highest standards in code quality and user experience.',
  },
];

const team = [
  {
    name: 'Alex Johnson',
    role: 'CEO & Founder',
    bio: '15+ years in tech leadership',
  },
  {
    name: 'Sarah Chen',
    role: 'CTO',
    bio: 'Full-stack architect & innovator',
  },
  {
    name: 'Michael Brown',
    role: 'Head of Design',
    bio: 'Award-winning UI/UX designer',
  },
  {
    name: 'Emily Davis',
    role: 'Lead Developer',
    bio: 'React & Next.js specialist',
  },
];

export default function AboutPage() {
  return (
    <>
      <Navigation />
      
      <main className="min-h-screen bg-black text-white pt-32 pb-20">
        {/* Hero Section */}
        <section className="container mx-auto px-6 mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl"
          >
            <h1 className="text-display font-black mb-6">
              About <span className="gradient-text">Jaspire</span>
            </h1>
            <p className="text-body-large text-gray-400 mb-8">
              We're a team of passionate developers, designers, and strategists dedicated to 
              crafting exceptional digital experiences that drive business growth.
            </p>
          </motion.div>
        </section>

        {/* Story Section */}
        <section className="container mx-auto px-6 mb-32">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <div className="space-y-4 text-gray-400">
                <p>
                  Founded in 2020, Jaspire emerged from a simple belief: businesses deserve 
                  web solutions that are not just functional, but exceptional.
                </p>
                <p>
                  What started as a small team of three developers has grown into a 
                  full-service digital agency, serving clients from startups to Fortune 500 
                  companies across the globe.
                </p>
                <p>
                  Today, we continue to push the boundaries of what's possible on the web, 
                  combining cutting-edge technology with timeless design principles to create 
                  experiences that users love and businesses rely on.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="glass rounded-2xl p-8">
                <div className="grid grid-cols-2 gap-8">
                  <div className="text-center">
                    <div className="text-4xl font-bold gradient-text mb-2">100+</div>
                    <div className="text-sm text-gray-500 uppercase">Projects</div>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold gradient-text mb-2">50+</div>
                    <div className="text-sm text-gray-500 uppercase">Clients</div>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold gradient-text mb-2">15+</div>
                    <div className="text-sm text-gray-500 uppercase">Team Members</div>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold gradient-text mb-2">5★</div>
                    <div className="text-sm text-gray-500 uppercase">Rating</div>
                  </div>
                </div>
              </div>
              {/* Decorative elements */}
              <div className="absolute -top-4 -right-4 w-32 h-32 bg-blue-500/20 rounded-full blur-3xl" />
              <div className="absolute -bottom-4 -left-4 w-40 h-40 bg-cyan-500/20 rounded-full blur-3xl" />
            </motion.div>
          </div>
        </section>

        {/* Values Section */}
        <section className="container mx-auto px-6 mb-32">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold mb-4">Our Values</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              The principles that guide every decision we make and every project we deliver.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <motion.div
                  key={value.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full glass glass-hover p-8">
                    <Icon className="w-12 h-12 text-blue-400 mb-4" />
                    <h3 className="text-xl font-bold mb-3">{value.title}</h3>
                    <p className="text-gray-400">{value.description}</p>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </section>

        {/* Team Section */}
        <section className="container mx-auto px-6 mb-32">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold mb-4">Meet the Team</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              The talented individuals who make the magic happen.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="glass glass-hover p-6 text-center">
                  <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 mx-auto mb-4 flex items-center justify-center">
                    <div className="w-[92px] h-[92px] rounded-full bg-black flex items-center justify-center">
                      <span className="text-3xl font-bold text-white">
                        {member.name.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                  </div>
                  <h3 className="text-lg font-bold mb-1">{member.name}</h3>
                  <p className="text-blue-400 text-sm mb-2">{member.role}</p>
                  <p className="text-gray-500 text-sm">{member.bio}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Process Section */}
        <section className="container mx-auto px-6 mb-32">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold mb-4">Our Process</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              A proven methodology that ensures project success from concept to launch.
            </p>
          </motion.div>

          <div className="max-w-4xl mx-auto">
            {['Discovery', 'Design', 'Development', 'Deployment'].map((step, index) => (
              <motion.div
                key={step}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center gap-8 mb-8"
              >
                <div className="flex-shrink-0 w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                  <span className="text-xl font-bold text-white">{index + 1}</span>
                </div>
                <div className="flex-1 glass rounded-xl p-6">
                  <h3 className="text-xl font-bold mb-2">{step}</h3>
                  <p className="text-gray-400">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                    Sed do eiusmod tempor incididunt ut labore.
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* CTA Section */}
        <section className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center glass rounded-2xl p-12"
          >
            <h2 className="text-3xl font-bold mb-4">
              Ready to Work Together?
            </h2>
            <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
              Let's create something amazing. Get in touch to discuss your project.
            </p>
            <Button
              variant="gradient"
              size="lg"
              className="btn-premium"
            >
              Get in Touch
            </Button>
          </motion.div>
        </section>
      </main>

      <Footer />
    </>
  );
}