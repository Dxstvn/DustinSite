'use client';

import { Button } from '@/components/ui/Button';
import { GlassPanel } from '@/components/ui/GlassPanel';
import { Card } from '@/components/ui/Card';
import { Navigation } from '@/components/layouts/Navigation';
import { Footer } from '@/components/layouts/Footer';
import { ScrollProgress } from '@/components/ui/ScrollProgress';
import { InteractiveCard } from '@/components/ui/InteractiveCard';
import { NewsletterSignup } from '@/components/ui/NewsletterSignup';
import { ScrollBlur } from '@/components/ui/ScrollBlur';
import { 
  DynamicThreeScene,
  DynamicContactForm,
  DynamicParallaxSection,
  DynamicParallaxText,
  DynamicParticleField,
  DynamicMagneticEffect,
  DynamicMagneticCard,
  DynamicTestimonialCarousel,
  DynamicClientLogos,
  DynamicMetricsCounter,
  DynamicTrustBadges
} from '@/components/dynamic/DynamicComponents';
import { ArrowRight, Code, Palette, Shield, Users, ChevronDown, Star, Globe, Rocket } from 'lucide-react';
import { motion } from 'framer-motion';
import { useScroll, useTransform } from 'framer-motion';
import { useRef, useEffect } from 'react';
// Lazy load GSAP only when needed
const loadGSAP = async () => {
  const { gsap } = await import('gsap');
  const { ScrollTrigger } = await import('gsap/ScrollTrigger');
  gsap.registerPlugin(ScrollTrigger);
  return { gsap, ScrollTrigger };
};
import { variants, sectionVariants, durations, easings, staggers } from '@/lib/animations';

// GSAP will be loaded dynamically when needed

const features = [
  {
    icon: Rocket,
    title: 'Lightning Performance',
    description: 'Achieve 99.9% uptime and <0.2s load times with our optimized infrastructure, progressive enhancement, and intelligent caching strategies that scale automatically.',
    color: 'from-purple-500 to-pink-500',
  },
  {
    icon: Palette,
    title: 'Conversion-Focused Design',
    description: 'Transform visitors into customers with data-driven UX/UI that increases conversions by 40% through psychological triggers and user journey optimization.',
    color: 'from-blue-500 to-cyan-500',
  },
  {
    icon: Shield,
    title: 'Enterprise Security',
    description: 'GDPR compliant, SOC 2 certified security with end-to-end encryption, automated vulnerability scanning, and 24/7 threat monitoring.',
    color: 'from-green-500 to-emerald-500',
  },
  {
    icon: Globe,
    title: 'Global Infrastructure',
    description: 'Deploy across 6 continents with CDN optimization, auto-scaling, and multi-region failover to serve millions of users simultaneously.',
    color: 'from-orange-500 to-red-500',
  },
  {
    icon: Code,
    title: 'Future-Ready Tech',
    description: 'Built on Next.js 15, React 19, and TypeScript with AI integration, headless architecture, and seamless third-party integrations.',
    color: 'from-indigo-500 to-purple-500',
  },
  {
    icon: Users,
    title: 'Growth-Driven Results',
    description: 'Data analytics, A/B testing, and user behavior tracking deliver measurable ROI improvements and sustainable business growth.',
    color: 'from-teal-500 to-blue-500',
  },
];

const stats = [
  { value: '250+', label: 'Projects Delivered' },
  { value: '99.9%', label: 'Uptime Guarantee' },
  { value: '40%', label: 'Avg. Conversion Increase' },
  { value: '48h', label: 'Launch Timeline' },
];

// Structured data for SEO
const structuredData = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": "https://jaspire.com/#organization",
      "name": "Jaspire",
      "url": "https://jaspire.com",
      "logo": {
        "@type": "ImageObject",
        "url": "https://jaspire.com/logo.png",
        "width": 200,
        "height": 60
      },
      "description": "Transform your business with high-converting websites and web applications. 48-hour launch, 340% average conversion increase.",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "San Francisco",
        "addressRegion": "CA",
        "addressCountry": "US"
      },
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "+1-555-JASPIRE",
        "contactType": "customer service",
        "availableLanguage": "English"
      },
      "sameAs": [
        "https://twitter.com/jaspire",
        "https://linkedin.com/company/jaspire",
        "https://github.com/jaspire"
      ]
    },
    {
      "@type": "WebSite",
      "@id": "https://jaspire.com/#website",
      "url": "https://jaspire.com",
      "name": "Jaspire - High-Converting Websites & Web Applications",
      "description": "Transform your business with high-converting websites and web applications. Trusted by 500+ companies worldwide.",
      "publisher": {
        "@id": "https://jaspire.com/#organization"
      },
      "potentialAction": {
        "@type": "SearchAction",
        "target": "https://jaspire.com/search?q={search_term_string}",
        "query-input": "required name=search_term_string"
      }
    },
    {
      "@type": "Service",
      "serviceType": "Web Development",
      "provider": {
        "@id": "https://jaspire.com/#organization"
      },
      "areaServed": "Worldwide",
      "hasOfferCatalog": {
        "@type": "OfferCatalog",
        "name": "Web Development Services",
        "itemListElement": [
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Website Development",
              "description": "High-converting websites that drive business results"
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Web Applications",
              "description": "Custom web applications built for scale and performance"
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Conversion Optimization",
              "description": "Data-driven optimization to increase your conversion rates"
            }
          }
        ]
      }
    }
  ]
};

export default function Home() {
  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ['start start', 'end start']
  });
  
  const heroOpacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const heroScale = useTransform(scrollYProgress, [0, 0.5], [1, 0.95]);
  
  useEffect(() => {
    // Dynamically load and initialize GSAP animations
    const initAnimations = async () => {
      try {
        const { gsap, ScrollTrigger } = await loadGSAP();
        
        // GSAP animations for hero text
        const tl = gsap.timeline();
        
        tl.fromTo('.hero-badge', 
          { opacity: 0, y: 30, scale: 0.9 },
          { opacity: 1, y: 0, scale: 1, duration: 0.8, ease: 'power3.out' }
        )
        .fromTo('.hero-title span', 
          { opacity: 0, y: 50 },
          { opacity: 1, y: 0, duration: 1, stagger: 0.2, ease: 'power3.out' },
          '-=0.4'
        )
        .fromTo('.hero-subtitle', 
          { opacity: 0, y: 30 },
          { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out' },
          '-=0.6'
        )
        .fromTo('.hero-cta', 
          { opacity: 0, y: 30 },
          { opacity: 1, y: 0, duration: 0.8, stagger: 0.1, ease: 'power3.out' },
          '-=0.4'
        );
        
        // Parallax for feature cards
        gsap.utils.toArray('.feature-card').forEach((card: any, i) => {
          gsap.fromTo(card,
            { opacity: 0, y: 100 },
            {
              opacity: 1,
              y: 0,
              duration: 1,
              delay: i * 0.1,
              ease: 'power3.out',
              scrollTrigger: {
                trigger: card,
                start: 'top 80%',
                toggleActions: 'play none none reverse',
              }
            }
          );
        });
        
        // Return cleanup function
        return () => {
          ScrollTrigger.getAll().forEach(trigger => trigger.kill());
        };
      } catch (error) {
        console.error('Error initializing animations:', error);
      }
    };

    initAnimations();
  }, []);
  
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />
      <ScrollProgress />
      <Navigation />
      
      {/* Premium visual effects */}
      <DynamicParticleField className="z-0" />
      
      {/* Noise texture overlay */}
      <div className="fixed inset-0 opacity-[0.015] pointer-events-none z-50" aria-hidden="true">
        <div className="absolute inset-0 noise-bg" />
      </div>
      
      <main id="main-content" className="min-h-screen bg-black text-white relative" role="main">
        {/* Hero Section */}
        <motion.section
          id="home"
          ref={heroRef}
          aria-labelledby="hero-heading"
          style={{ opacity: heroOpacity, scale: heroScale }}
          className="relative min-h-screen flex items-center justify-center overflow-hidden"
        >
          {/* Three.js Background */}
          <DynamicThreeScene className="absolute inset-0" />
          
          {/* Grid overlay */}
          <div className="absolute inset-0 grid-bg opacity-[0.02] pointer-events-none" />
          
          <div className="container mx-auto px-4 md:px-8 lg:px-[var(--container-padding-desktop)] relative z-10" style={{ maxWidth: 'var(--container-max-width)' }}>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8 }}
              className="text-center max-w-4xl mx-auto pt-[var(--spacing-6xl)] pb-[var(--spacing-5xl)]"
            >
              {/* Premium Badge */}
              <div className="hero-badge inline-flex items-center gap-[var(--spacing-xs)] px-[var(--spacing-md)] py-[var(--spacing-sm)] rounded-full glass mb-[var(--spacing-2xl)] group cursor-pointer">
                <Star className="w-4 h-4 text-yellow-400" />
                <span className="text-sm font-medium text-gray-300">Trusted by 500+ Companies Worldwide</span>
                <ArrowRight className="w-3 h-3 text-gray-400 group-hover:translate-x-1 transition-transform" />
              </div>
              
              {/* Main Heading */}
              <ScrollBlur maxBlur={5} fadeOut={false}>
                <h1 id="hero-heading" className="hero-title text-display font-black mb-[var(--spacing-3xl)]">
                  <DynamicParallaxText speed={0.2} direction="up">
                    <span className="block">We Build</span>
                  </DynamicParallaxText>
                  <DynamicParallaxText speed={0.3} direction="up">
                    <span className="block gradient-text-animated">Digital Excellence</span>
                  </DynamicParallaxText>
                </h1>
              </ScrollBlur>
              
              {/* Subheading */}
              <p className="hero-subtitle text-body-large max-w-3xl mx-auto mb-[var(--spacing-xl)]">
                We build high-converting websites and web applications that drive real business results. 
                From concept to launch in 48 hours, with ongoing optimization that grows your revenue.
              </p>
              
              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-[var(--spacing-lg)] justify-center items-center">
                <div className="hero-cta">
                  <DynamicMagneticEffect strength={0.3} asDiv={true}>
                    <Button 
                      size="lg" 
                      variant="gradient" 
                      className="btn-premium min-w-[200px] h-[56px] text-base font-semibold glow-subtle"
                    >
                      Start Your Project
                      <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>
                  </DynamicMagneticEffect>
                </div>
                <div className="hero-cta">
                  <DynamicMagneticEffect strength={0.3} asDiv={true}>
                    <Button 
                      size="lg" 
                      variant="outline" 
                      className="glass glass-hover min-w-[200px] h-[56px] text-base font-semibold"
                    >
                      View Case Studies
                    </Button>
                  </DynamicMagneticEffect>
                </div>
              </div>

              {/* Stats Row */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="grid grid-cols-2 md:grid-cols-4 gap-[var(--spacing-lg)] mt-[var(--spacing-4xl)] pt-[var(--spacing-4xl)] border-t border-white/5"
              >
                {stats.map((stat, index) => (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.7 + index * 0.1 }}
                    className="text-center"
                  >
                    <div className="text-3xl md:text-4xl font-bold gradient-text mb-2">
                      {stat.value}
                    </div>
                    <div className="text-sm text-gray-500 uppercase tracking-wider">
                      {stat.label}
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            </motion.div>
            
            {/* Scroll indicator */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
              className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
            >
              <motion.div
                animate={{ y: [0, 8, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="flex flex-col items-center gap-2 cursor-pointer"
              >
                <span className="text-xs text-gray-500 uppercase tracking-wider">Scroll</span>
                <ChevronDown className="w-5 h-5 text-gray-400" />
              </motion.div>
            </motion.div>
          </div>
        </motion.section>

        {/* Features Section */}
        <DynamicParallaxSection speed={0.1} className="relative">
          <section id="services" className="py-[var(--section-padding)]">
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-blue-900/5 to-transparent" />
            <div className="container mx-auto px-4 md:px-8 lg:px-[var(--container-padding-desktop)] relative" style={{ maxWidth: 'var(--container-max-width)' }}>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-center mb-[var(--spacing-4xl)]"
              >
                <h2 className="text-title font-bold mb-[var(--spacing-md)]">
                  Why Growing Companies Choose{' '}
                  <span className="gradient-text">Jaspire</span>
                </h2>
                <p className="text-body-large max-w-3xl mx-auto">
                  We don't just build websites—we craft digital experiences that convert visitors into customers, 
                  scale with your growth, and deliver measurable ROI from day one.
                </p>
              </motion.div>

            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-[var(--spacing-lg)]"
              variants={variants.container}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
            >
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <motion.div
                    key={feature.title}
                    variants={variants.item}
                    custom={index}
                    whileHover={{ 
                      y: -8,
                      transition: { 
                        duration: durations.fast,
                        ease: easings.outExpo 
                      }
                    }}
                  >
                    <DynamicMagneticCard strength={0.15} className="feature-card h-full">
                      <InteractiveCard className="h-full">
                        <Card className="h-full glass glass-hover group cursor-pointer p-[var(--spacing-lg)] card-hover">
                          <div className="flex flex-col h-full">
                        <div className={`w-[48px] h-[48px] rounded-xl bg-gradient-to-br ${feature.color} p-0.5 mb-[var(--spacing-md)]`}>
                          <div className="w-full h-full rounded-[10px] bg-black flex items-center justify-center">
                            <Icon className="w-6 h-6 text-white" />
                          </div>
                        </div>
                        <h3 className="text-2xl font-bold text-white mb-[var(--spacing-sm)]">
                          {feature.title}
                        </h3>
                        <p className="text-gray-400 leading-relaxed flex-grow">
                          {feature.description}
                        </p>
                        <div className="mt-[var(--spacing-md)] flex items-center text-blue-400 font-medium">
                          Learn more
                          <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-2 transition-transform" />
                        </div>
                          </div>
                        </Card>
                      </InteractiveCard>
                    </DynamicMagneticCard>
                  </motion.div>
                );
              })}
            </motion.div>
            </div>
          </section>
        </DynamicParallaxSection>

        {/* Social Proof Section */}
        <section className="py-[var(--section-padding)] relative">
          <div className="container mx-auto px-4 md:px-8 lg:px-[var(--container-padding-desktop)]" style={{ maxWidth: 'var(--container-max-width)' }}>
            {/* Client Logos */}
            <DynamicClientLogos variant="marquee" className="mb-[var(--spacing-5xl)]" />
            
            {/* Metrics Counter */}
            <DynamicMetricsCounter className="mb-[var(--spacing-5xl)]" />
            
            {/* Testimonials */}
            <div className="mb-[var(--spacing-5xl)]">
              <div className="text-center mb-[var(--spacing-2xl)]">
                <h2 className="text-title font-bold mb-[var(--spacing-md)]">
                  What Our <span className="gradient-text">Clients Say</span>
                </h2>
                <p className="text-body-large max-w-3xl mx-auto">
                  Don't just take our word for it. Here's what business leaders say about 
                  working with Jaspire and the results we've delivered.
                </p>
              </div>
              <DynamicTestimonialCarousel />
            </div>
            
            {/* Trust Badges */}
            <DynamicTrustBadges variant="compact" />
          </div>
        </section>

        {/* CTA Section */}
        <motion.section 
          id="contact" 
          className="py-[var(--section-padding)] relative"
          variants={sectionVariants}
          initial="offscreen"
          whileInView="onscreen"
          viewport={{ once: true, amount: 0.3 }}
        >
          <div className="container mx-auto px-4 md:px-8 lg:px-[var(--container-padding-desktop)]" style={{ maxWidth: 'var(--container-max-width)' }}>
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{
                duration: durations.slow,
                ease: easings.outExpo,
              }}
              className="relative"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-cyan-600/20 blur-3xl" />
              <GlassPanel className="relative p-[var(--spacing-3xl)] md:p-[var(--spacing-5xl)] text-center overflow-hidden">
                {/* Background decoration */}
                <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
                <div className="absolute bottom-0 left-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl" />
                
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="relative z-10"
                >
                  <h2 className="text-title font-bold mb-[var(--spacing-md)]">
                    Ready to{' '}
                    <span className="gradient-text">Transform Your Business?</span>
                  </h2>
                  <p className="text-body-large mb-[var(--spacing-2xl)] max-w-2xl mx-auto">
                    Get a free consultation and project roadmap. We'll analyze your current performance 
                    and show you exactly how we can increase your conversions within 30 days.
                  </p>
                  
                  {/* Contact Form */}
                  <DynamicContactForm />
                </motion.div>
              </GlassPanel>
            </motion.div>
          </div>
        </motion.section>

        {/* Newsletter Section */}
        <section className="py-[var(--spacing-4xl)] relative">
          <div className="container mx-auto px-4 md:px-8 lg:px-[var(--container-padding-desktop)]" style={{ maxWidth: 'var(--container-max-width)' }}>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-[var(--spacing-2xl)] items-center">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: durations.slow, ease: easings.outExpo }}
              >
                <h2 className="text-3xl font-bold mb-[var(--spacing-sm)]">
                  Get <span className="gradient-text">Growth Insights</span>
                </h2>
                <p className="text-gray-400 text-lg">
                  Join 5,000+ business owners getting weekly case studies, conversion tips, 
                  and exclusive strategies that drive real results.
                </p>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: durations.slow, ease: easings.outExpo }}
              >
                <NewsletterSignup />
              </motion.div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </>
  );
}