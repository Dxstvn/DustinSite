import type { Metadata, Viewport } from "next";
import { Suspense } from 'react';
import { inter, jetbrainsMono } from '@/lib/fonts';
import { SmoothScrollProvider } from '@/components/providers/SmoothScrollProvider';
import { PageTransition } from '@/components/providers/PageTransition';
import { RouteLoader, FullPageLoader } from '@/components/ui/RouteLoader';
import { ToastProvider } from '@/components/ui/Toast';
import { ErrorBoundary } from '@/components/ui/ErrorBoundary';
import { ErrorSuppressor } from '@/components/providers/ErrorSuppressor';
import { ImagePreloader } from '@/components/ui/ImagePreloader';
import { SkipLinks } from '@/components/ui/SkipLinks';
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: 'Jaspire - High-Converting Websites & Web Applications',
    template: '%s | Jaspire'
  },
  description: 'Transform your business with high-converting websites and web applications. 48-hour launch, 340% average conversion increase, trusted by 500+ companies worldwide.',
  keywords: [
    'web development',
    'website design', 
    'web applications',
    'conversion optimization',
    'digital transformation',
    'business growth',
    'React development',
    'Next.js development',
    'enterprise web solutions'
  ],
  authors: [{ name: 'Jaspire Team' }],
  creator: 'Jaspire',
  publisher: 'Jaspire',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL('https://jaspire.com'),
  alternates: {
    canonical: '/',
  },
  openGraph: {
    title: 'Jaspire - High-Converting Websites & Web Applications',
    description: 'Transform your business with high-converting websites and web applications. 48-hour launch, 340% average conversion increase, trusted by 500+ companies worldwide.',
    url: 'https://jaspire.com',
    siteName: 'Jaspire',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'Jaspire - High-Converting Websites & Web Applications',
      },
    ],
    locale: 'en_US',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Jaspire - High-Converting Websites & Web Applications',
    description: 'Transform your business with high-converting websites and web applications. 48-hour launch, 340% average conversion increase.',
    images: ['/og-image.png'],
    creator: '@jaspire',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  verification: {
    google: 'your-google-verification-code',
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
    { media: '(prefers-color-scheme: dark)', color: '#000000' },
  ],
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${inter.variable} ${jetbrainsMono.variable} font-sans antialiased`}
      >
        <SkipLinks />
        <ErrorSuppressor>
          <ErrorBoundary>
            <ToastProvider>
              <RouteLoader />
              <ImagePreloader />
              <Suspense fallback={<FullPageLoader />}>
                <SmoothScrollProvider>
                  <PageTransition>
                    {children}
                  </PageTransition>
                </SmoothScrollProvider>
              </Suspense>
            </ToastProvider>
          </ErrorBoundary>
        </ErrorSuppressor>
      </body>
    </html>
  );
}
