'use client';

import { Navigation } from '@/components/layouts/Navigation';
import { Footer } from '@/components/layouts/Footer';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { ExternalLink, Github, Globe, Award } from 'lucide-react';
import Image from 'next/image';

const projects = [
  {
    id: 1,
    title: 'E-Commerce Platform',
    client: 'TechStore Pro',
    description: 'A modern e-commerce platform with real-time inventory, AI-powered recommendations, and seamless checkout.',
    image: '/projects/ecommerce.jpg',
    tags: ['Next.js', 'TypeScript', 'Stripe', 'PostgreSQL'],
    stats: {
      conversion: '+45%',
      performance: '98/100',
      users: '50K+',
    },
    links: {
      live: 'https://example.com',
      github: 'https://github.com',
    },
    featured: true,
  },
  {
    id: 2,
    title: 'SaaS Dashboard',
    client: 'DataFlow Analytics',
    description: 'Real-time analytics dashboard with advanced data visualization and collaborative features.',
    image: '/projects/dashboard.jpg',
    tags: ['React', 'D3.js', 'WebSocket', 'Node.js'],
    stats: {
      uptime: '99.9%',
      response: '<100ms',
      clients: '200+',
    },
    links: {
      live: 'https://example.com',
    },
    featured: true,
  },
  {
    id: 3,
    title: 'Mobile Banking App',
    client: 'FinTech Solutions',
    description: 'Secure mobile banking application with biometric authentication and instant transfers.',
    image: '/projects/banking.jpg',
    tags: ['React Native', 'GraphQL', 'AWS', 'Blockchain'],
    stats: {
      security: 'A+',
      downloads: '100K+',
      rating: '4.8★',
    },
    links: {
      live: 'https://example.com',
    },
    featured: false,
  },
];

export default function WorkPage() {
  return (
    <>
      <Navigation />
      
      <main className="min-h-screen bg-black text-white pt-32 pb-20">
        {/* Hero Section */}
        <section className="container mx-auto px-6 mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl"
          >
            <h1 className="text-display font-black mb-6">
              Our <span className="gradient-text">Work</span>
            </h1>
            <p className="text-body-large text-gray-400 mb-8">
              Explore our portfolio of successful projects that have transformed businesses 
              and delighted users across industries.
            </p>
            
            {/* Stats */}
            <div className="flex flex-wrap gap-8 mt-12">
              <div>
                <div className="text-3xl font-bold gradient-text">50+</div>
                <div className="text-sm text-gray-500 uppercase tracking-wider">Projects Delivered</div>
              </div>
              <div>
                <div className="text-3xl font-bold gradient-text">30+</div>
                <div className="text-sm text-gray-500 uppercase tracking-wider">Happy Clients</div>
              </div>
              <div>
                <div className="text-3xl font-bold gradient-text">5★</div>
                <div className="text-sm text-gray-500 uppercase tracking-wider">Average Rating</div>
              </div>
            </div>
          </motion.div>
        </section>

        {/* Featured Projects */}
        <section className="container mx-auto px-6">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl font-bold mb-12"
          >
            Featured Projects
          </motion.h2>

          <div className="space-y-32">
            {projects.filter(p => p.featured).map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${
                  index % 2 === 1 ? 'lg:flex-row-reverse' : ''
                }`}
              >
                {/* Project Image */}
                <div className={`relative group ${index % 2 === 1 ? 'lg:order-2' : ''}`}>
                  <div className="relative overflow-hidden rounded-2xl glass">
                    <div className="aspect-video bg-gradient-to-br from-blue-900/20 to-cyan-900/20 flex items-center justify-center">
                      <Globe className="w-20 h-20 text-gray-700" />
                    </div>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  </div>
                  {/* Decorative elements */}
                  <div className="absolute -top-4 -right-4 w-24 h-24 bg-blue-500/20 rounded-full blur-2xl" />
                  <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-cyan-500/20 rounded-full blur-2xl" />
                </div>

                {/* Project Info */}
                <div className={index % 2 === 1 ? 'lg:order-1' : ''}>
                  <div className="space-y-6">
                    <div>
                      <p className="text-blue-400 font-medium mb-2">{project.client}</p>
                      <h3 className="text-4xl font-bold mb-4">{project.title}</h3>
                      <p className="text-gray-400 text-lg leading-relaxed">
                        {project.description}
                      </p>
                    </div>

                    {/* Tech Stack */}
                    <div className="flex flex-wrap gap-2">
                      {project.tags.map((tag) => (
                        <span
                          key={tag}
                          className="px-3 py-1 text-sm glass rounded-full text-gray-300"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    {/* Stats */}
                    <div className="grid grid-cols-3 gap-4">
                      {Object.entries(project.stats).map(([key, value]) => (
                        <div key={key} className="text-center p-3 glass rounded-lg">
                          <div className="text-xl font-bold text-white">{value}</div>
                          <div className="text-xs text-gray-500 uppercase">{key}</div>
                        </div>
                      ))}
                    </div>

                    {/* Links */}
                    <div className="flex gap-4">
                      {project.links.live && (
                        <Button
                          variant="gradient"
                          size="md"
                          className="btn-premium"
                        >
                          <ExternalLink className="mr-2 w-4 h-4" />
                          View Live
                        </Button>
                      )}
                      {project.links.github && (
                        <Button
                          variant="outline"
                          size="md"
                          className="glass glass-hover"
                        >
                          <Github className="mr-2 w-4 h-4" />
                          Source Code
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Other Projects Grid */}
        <section className="container mx-auto px-6 mt-32">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl font-bold mb-12"
          >
            More Projects
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.filter(p => !p.featured).map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full glass glass-hover group cursor-pointer p-6">
                  <div className="space-y-4">
                    <div className="aspect-video bg-gradient-to-br from-blue-900/20 to-cyan-900/20 rounded-lg flex items-center justify-center">
                      <Globe className="w-12 h-12 text-gray-700" />
                    </div>
                    <div>
                      <p className="text-blue-400 text-sm font-medium mb-1">{project.client}</p>
                      <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                      <p className="text-gray-400 text-sm line-clamp-2">
                        {project.description}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {project.tags.slice(0, 3).map((tag) => (
                        <span
                          key={tag}
                          className="px-2 py-1 text-xs glass rounded-full text-gray-400"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        {/* CTA Section */}
        <section className="container mx-auto px-6 mt-32">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center glass rounded-2xl p-12"
          >
            <h2 className="text-3xl font-bold mb-4">
              Have a Project in Mind?
            </h2>
            <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
              Let's discuss how we can help bring your vision to life with our expertise.
            </p>
            <Button
              variant="gradient"
              size="lg"
              className="btn-premium"
            >
              Start a Project
            </Button>
          </motion.div>
        </section>
      </main>

      <Footer />
    </>
  );
}