'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/Button';
import { ArrowLeft, Home, Search } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function NotFound() {
  const router = useRouter();

  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-black to-cyan-900/20" />
      
      {/* Grid pattern */}
      <div className="absolute inset-0 grid-bg opacity-[0.02]" />
      
      {/* Animated background orbs */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse-slow" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse-slow" />
      
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-2xl mx-auto"
        >
          {/* 404 Number */}
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="mb-8"
          >
            <h1 className="text-[150px] md:text-[200px] font-black leading-none gradient-text-animated">
              404
            </h1>
          </motion.div>
          
          {/* Error message */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="space-y-4 mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white">
              Page Not Found
            </h2>
            <p className="text-lg text-gray-400 max-w-md mx-auto">
              The page you're looking for doesn't exist or has been moved. 
              Let's get you back on track.
            </p>
          </motion.div>
          
          {/* Action buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Button
              onClick={() => router.back()}
              variant="outline"
              size="lg"
              className="glass glass-hover min-w-[160px]"
            >
              <ArrowLeft className="mr-2 w-4 h-4" />
              Go Back
            </Button>
            
            <Link href="/">
              <Button
                variant="gradient"
                size="lg"
                className="btn-premium min-w-[160px]"
              >
                <Home className="mr-2 w-4 h-4" />
                Home Page
              </Button>
            </Link>
          </motion.div>
          
          {/* Helpful links */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.6 }}
            className="mt-16 pt-8 border-t border-white/10"
          >
            <p className="text-sm text-gray-500 mb-4">Here are some helpful links:</p>
            <div className="flex flex-wrap gap-4 justify-center text-sm">
              <Link href="/services" className="text-blue-400 hover:text-blue-300 transition-colors">
                Services
              </Link>
              <span className="text-gray-600">•</span>
              <Link href="/work" className="text-blue-400 hover:text-blue-300 transition-colors">
                Our Work
              </Link>
              <span className="text-gray-600">•</span>
              <Link href="/about" className="text-blue-400 hover:text-blue-300 transition-colors">
                About Us
              </Link>
              <span className="text-gray-600">•</span>
              <Link href="/contact" className="text-blue-400 hover:text-blue-300 transition-colors">
                Contact
              </Link>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}