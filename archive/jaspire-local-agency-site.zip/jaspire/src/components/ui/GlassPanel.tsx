'use client';

import * as React from 'react';
import { cn } from '@/lib/utils';

interface GlassPanelProps extends React.HTMLAttributes<HTMLDivElement> {
  blur?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl';
  opacity?: number;
  border?: boolean;
  shadow?: boolean;
}

const GlassPanel = React.forwardRef<HTMLDivElement, GlassPanelProps>(
  (
    { 
      className, 
      blur = 'xl', 
      opacity = 5, 
      border = true, 
      shadow = true, 
      children, 
      ...props 
    }, 
    ref
  ) => {
    const blurClasses = {
      sm: 'backdrop-blur-sm',
      md: 'backdrop-blur-md',
      lg: 'backdrop-blur-lg',
      xl: 'backdrop-blur-xl',
      '2xl': 'backdrop-blur-2xl',
      '3xl': 'backdrop-blur-3xl',
    };

    return (
      <div
        ref={ref}
        className={cn(
          'relative overflow-hidden rounded-xl',
          blurClasses[blur],
          {
            'border border-white/10': border,
            'shadow-glass': shadow,
          },
          className
        )}
        style={{
          backgroundColor: `rgba(255, 255, 255, 0.${opacity.toString().padStart(2, '0')}`,
        }}
        {...props}
      >
        {/* Gradient overlay for enhanced glass effect */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent pointer-events-none" />
        
        {/* Content */}
        <div className="relative z-10">{children}</div>
      </div>
    );
  }
);

GlassPanel.displayName = 'GlassPanel';

export { GlassPanel };