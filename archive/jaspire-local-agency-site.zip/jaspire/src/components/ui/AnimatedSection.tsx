'use client';

import { motion } from 'framer-motion';
import { ReactNode } from 'react';
import { sectionVariants } from '@/lib/animations';

interface AnimatedSectionProps {
  children: ReactNode;
  className?: string;
  delay?: number;
}

export function AnimatedSection({ 
  children, 
  className = '',
  delay = 0 
}: AnimatedSectionProps) {
  return (
    <motion.div
      variants={sectionVariants}
      initial="offscreen"
      whileInView="onscreen"
      viewport={{ once: true, amount: 0.3 }}
      transition={{ delay }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export function FadeIn({ 
  children, 
  className = '',
  delay = 0,
  duration = 0.5 
}: AnimatedSectionProps & { duration?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ 
        delay,
        duration,
        ease: [0.19, 1, 0.22, 1] // ease-out-expo
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export function StaggerContainer({ 
  children, 
  className = '',
  stagger = 0.1 
}: AnimatedSectionProps & { stagger?: number }) {
  return (
    <motion.div
      initial="initial"
      whileInView="animate"
      viewport={{ once: true }}
      variants={{
        initial: {},
        animate: {
          transition: {
            staggerChildren: stagger,
          },
        },
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export function StaggerItem({ 
  children, 
  className = '' 
}: AnimatedSectionProps) {
  return (
    <motion.div
      variants={{
        initial: { y: 20, opacity: 0 },
        animate: { 
          y: 0, 
          opacity: 1,
          transition: {
            duration: 0.5,
            ease: [0.19, 1, 0.22, 1],
          },
        },
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
}