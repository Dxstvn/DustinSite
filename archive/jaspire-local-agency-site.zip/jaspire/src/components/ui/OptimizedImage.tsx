'use client';

import { useState, useRef, useEffect } from 'react';
import Image, { ImageProps } from 'next/image';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { imageConfigs, imageUtils, type ImageConfig } from '@/lib/image-config';

interface OptimizedImageProps extends Omit<ImageProps, 'placeholder' | 'blurDataURL'> {
  className?: string;
  containerClassName?: string;
  showLoader?: boolean;
  blurHash?: string;
  fallbackSrc?: string;
  lazy?: boolean;
  configType?: keyof typeof imageConfigs;
}

// Generate blur placeholder from dimensions
const generateBlurPlaceholder = (width: number, height: number): string => {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  
  if (!ctx) return '';
  
  canvas.width = 10;
  canvas.height = Math.round((height / width) * 10);
  
  // Create gradient blur effect
  const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
  gradient.addColorStop(0, '#1a1a2e');
  gradient.addColorStop(0.5, '#16213e');
  gradient.addColorStop(1, '#0f3460');
  
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  
  return canvas.toDataURL('image/jpeg', 0.1);
};

export function OptimizedImage({
  src,
  alt,
  width,
  height,
  className,
  containerClassName,
  showLoader = true,
  blurHash,
  fallbackSrc,
  lazy = true,
  priority = false,
  configType = 'features',
  ...props
}: OptimizedImageProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [imageSrc, setImageSrc] = useState(src);
  const [blurDataURL, setBlurDataURL] = useState<string>('');
  const imgRef = useRef<HTMLImageElement>(null);
  
  // Get configuration for image type
  const config = imageConfigs[configType];
  
  // Generate blur placeholder
  useEffect(() => {
    if (!blurHash && config.blur && typeof width === 'number' && typeof height === 'number') {
      const placeholder = imageUtils.generateBlurDataURL(width, height);
      setBlurDataURL(placeholder);
    }
  }, [width, height, blurHash, config.blur]);

  const handleLoad = () => {
    setIsLoading(false);
    setHasError(false);
  };

  const handleError = () => {
    setIsLoading(false);
    setHasError(true);
    
    if (fallbackSrc && imageSrc !== fallbackSrc) {
      setImageSrc(fallbackSrc);
      setIsLoading(true);
      setHasError(false);
    }
  };

  // WebP support detection
  const supportsWebP = useRef<boolean | null>(null);
  
  useEffect(() => {
    if (supportsWebP.current === null) {
      const canvas = document.createElement('canvas');
      canvas.width = 1;
      canvas.height = 1;
      supportsWebP.current = canvas.toDataURL('image/webp').indexOf('data:image/webp') === 0;
    }
  }, []);

  // Optimize image source based on device capabilities and config
  const getOptimizedSrc = (originalSrc: string | any) => {
    if (typeof originalSrc !== 'string') return originalSrc;
    return imageUtils.getOptimizedSrc(originalSrc, config);
  };

  // Responsive sizes based on container and config
  const getResponsiveSizes = () => {
    if (props.sizes) return props.sizes;
    return config.sizes || '(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw';
  };

  if (hasError && !fallbackSrc) {
    return (
      <div 
        className={cn(
          'flex items-center justify-center bg-gray-200 text-gray-500',
          containerClassName
        )}
        style={{ width, height }}
      >
        <div className="text-center p-4">
          <div className="text-sm mb-2">Image failed to load</div>
          <div className="text-xs text-gray-400">{alt}</div>
        </div>
      </div>
    );
  }

  return (
    <div className={cn('relative overflow-hidden', containerClassName)}>
      <AnimatePresence>
        {isLoading && showLoader && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="absolute inset-0 flex items-center justify-center bg-gray-100 z-10"
          >
            {/* Skeleton loader */}
            <div className="absolute inset-0 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 animate-pulse">
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent"
                animate={{ x: ['-100%', '100%'] }}
                transition={{ 
                  duration: 1.5, 
                  repeat: Infinity, 
                  ease: 'linear' 
                }}
                style={{ width: '50%' }}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <Image
        ref={imgRef}
        src={getOptimizedSrc(imageSrc)}
        alt={alt}
        width={width}
        height={height}
        className={cn(
          'transition-opacity duration-300',
          isLoading ? 'opacity-0' : 'opacity-100',
          className
        )}
        sizes={getResponsiveSizes()}
        priority={priority}
        placeholder={blurDataURL || blurHash ? 'blur' : 'empty'}
        blurDataURL={blurDataURL || blurHash}
        quality={config.quality}
        onLoad={handleLoad}
        onError={handleError}
        loading={lazy && !priority ? 'lazy' : 'eager'}
        {...props}
      />
    </div>
  );
}

// Optimized background image component
interface OptimizedBackgroundImageProps {
  src: string;
  alt: string;
  children?: React.ReactNode;
  className?: string;
  overlay?: boolean;
  overlayOpacity?: number;
}

export function OptimizedBackgroundImage({
  src,
  alt,
  children,
  className,
  overlay = false,
  overlayOpacity = 0.5,
}: OptimizedBackgroundImageProps) {
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <div className={cn('relative overflow-hidden', className)}>
      <OptimizedImage
        src={src}
        alt={alt}
        fill
        className={cn(
          'object-cover transition-opacity duration-700',
          isLoaded ? 'opacity-100' : 'opacity-0'
        )}
        onLoad={() => setIsLoaded(true)}
        priority
      />
      
      {overlay && (
        <div 
          className="absolute inset-0 bg-black z-10"
          style={{ opacity: overlayOpacity }}
        />
      )}
      
      {children && (
        <div className="relative z-20">
          {children}
        </div>
      )}
    </div>
  );
}

// Image gallery with progressive loading
interface ImageGalleryProps {
  images: Array<{
    src: string;
    alt: string;
    width?: number;
    height?: number;
  }>;
  className?: string;
  columns?: number;
}

export function OptimizedImageGallery({
  images,
  className,
  columns = 3,
}: ImageGalleryProps) {
  const [visibleCount, setVisibleCount] = useState(columns * 2); // Load 2 rows initially
  const [isLoadingMore, setIsLoadingMore] = useState(false);

  const loadMore = async () => {
    if (isLoadingMore || visibleCount >= images.length) return;
    
    setIsLoadingMore(true);
    
    // Simulate loading delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    setVisibleCount(prev => Math.min(prev + columns * 2, images.length));
    setIsLoadingMore(false);
  };

  useEffect(() => {
    const handleScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = document.documentElement;
      
      if (scrollTop + clientHeight >= scrollHeight - 100 && !isLoadingMore) {
        loadMore();
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isLoadingMore, visibleCount, images.length]);

  return (
    <div className={className}>
      <div 
        className="grid gap-4"
        style={{ gridTemplateColumns: `repeat(${columns}, 1fr)` }}
      >
        {images.slice(0, visibleCount).map((image, index) => (
          <motion.div
            key={`${image.src}-${index}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: (index % (columns * 2)) * 0.1 }}
          >
            <OptimizedImage
              src={image.src}
              alt={image.alt}
              width={image.width || 400}
              height={image.height || 300}
              className="w-full h-auto rounded-lg"
              lazy={index >= columns} // First row eager, rest lazy
            />
          </motion.div>
        ))}
      </div>
      
      {visibleCount < images.length && (
        <div className="text-center mt-8">
          {isLoadingMore ? (
            <div className="text-gray-500">Loading more images...</div>
          ) : (
            <button
              onClick={loadMore}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Load More
            </button>
          )}
        </div>
      )}
    </div>
  );
}