'use client';

import { useEffect, useRef, useState } from 'react';
import { motion, useMotionValue, useSpring } from 'framer-motion';
import { gsap } from 'gsap';

export function CustomCursor() {
  const [isHovering, setIsHovering] = useState(false);
  const [isClicking, setIsClicking] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  
  const cursorX = useMotionValue(0);
  const cursorY = useMotionValue(0);
  
  const springConfig = { damping: 20, stiffness: 300 };
  const cursorXSpring = useSpring(cursorX, springConfig);
  const cursorYSpring = useSpring(cursorY, springConfig);

  const dotRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Check if device has a mouse
    const hasPointer = window.matchMedia('(pointer: fine)').matches;
    if (!hasPointer) return;

    setIsVisible(true);

    const updateCursor = (e: MouseEvent) => {
      cursorX.set(e.clientX);
      cursorY.set(e.clientY);
    };

    const handleMouseEnter = () => setIsVisible(true);
    const handleMouseLeave = () => setIsVisible(false);
    const handleMouseDown = () => setIsClicking(true);
    const handleMouseUp = () => setIsClicking(false);

    // Add interactive class detection
    const handleElementHover = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const isInteractive = 
        target.matches('button, a, input, textarea, select, [role="button"], .cursor-pointer') ||
        target.closest('button, a, input, textarea, select, [role="button"], .cursor-pointer');
      
      setIsHovering(!!isInteractive);
    };

    window.addEventListener('mousemove', updateCursor);
    window.addEventListener('mousemove', handleElementHover);
    document.addEventListener('mouseenter', handleMouseEnter);
    document.addEventListener('mouseleave', handleMouseLeave);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);

    // Hide default cursor
    document.body.style.cursor = 'none';

    return () => {
      window.removeEventListener('mousemove', updateCursor);
      window.removeEventListener('mousemove', handleElementHover);
      document.removeEventListener('mouseenter', handleMouseEnter);
      document.removeEventListener('mouseleave', handleMouseLeave);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      document.body.style.cursor = 'auto';
    };
  }, [cursorX, cursorY]);

  // Magnetic effect for interactive elements
  useEffect(() => {
    if (!isVisible) return;

    const magneticElements = document.querySelectorAll('.magnetic');
    
    magneticElements.forEach((elem) => {
      const handleMouseMove = (e: MouseEvent) => {
        const rect = (elem as HTMLElement).getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;
        
        gsap.to(elem, {
          x: x * 0.3,
          y: y * 0.3,
          duration: 0.3,
        });
      };

      const handleMouseLeave = () => {
        gsap.to(elem, {
          x: 0,
          y: 0,
          duration: 0.3,
        });
      };

      elem.addEventListener('mousemove', handleMouseMove as EventListener);
      elem.addEventListener('mouseleave', handleMouseLeave);

      return () => {
        elem.removeEventListener('mousemove', handleMouseMove as EventListener);
        elem.removeEventListener('mouseleave', handleMouseLeave);
      };
    });
  }, [isVisible]);

  if (!isVisible) return null;

  return (
    <>
      {/* Cursor dot */}
      <motion.div
        ref={dotRef}
        className="fixed top-0 left-0 w-2 h-2 -translate-x-1/2 -translate-y-1/2 pointer-events-none z-[9999] mix-blend-difference"
        style={{
          x: cursorXSpring,
          y: cursorYSpring,
        }}
      >
        <div className={`w-full h-full bg-white rounded-full transition-transform duration-200 ${
          isClicking ? 'scale-75' : isHovering ? 'scale-150' : 'scale-100'
        }`} />
      </motion.div>

      {/* Cursor ring */}
      <motion.div
        ref={ringRef}
        className="fixed top-0 left-0 w-8 h-8 -translate-x-1/2 -translate-y-1/2 pointer-events-none z-[9998]"
        style={{
          x: cursorXSpring,
          y: cursorYSpring,
        }}
      >
        <div className={`w-full h-full border border-white/30 rounded-full transition-all duration-300 ${
          isClicking ? 'scale-90 border-white/50' : isHovering ? 'scale-150 border-blue-400/50' : 'scale-100'
        }`} />
      </motion.div>
    </>
  );
}