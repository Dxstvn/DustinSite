'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from './Button';
import { useToast } from './Toast';
import { Mail, ArrowRight, CheckCircle, Sparkles } from 'lucide-react';
import { durations, easings } from '@/lib/animations';
import { cn } from '@/lib/utils';

interface NewsletterSignupProps {
  variant?: 'default' | 'compact' | 'inline';
  className?: string;
}

export function NewsletterSignup({ 
  variant = 'default',
  className 
}: NewsletterSignupProps) {
  const { addToast } = useToast();
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isFocused, setIsFocused] = useState(false);

  const validateEmail = (email: string): boolean => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email.trim()) {
      setError('Email is required');
      return;
    }

    if (!validateEmail(email)) {
      setError('Please enter a valid email');
      return;
    }

    setIsSubmitting(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setIsSuccess(true);
      addToast({
        type: 'success',
        title: 'Welcome aboard! 🎉',
        message: 'Check your email to confirm subscription.',
      });
      
      // Reset after delay
      setTimeout(() => {
        setEmail('');
        setIsSuccess(false);
      }, 3000);
    } catch (error) {
      setError('Something went wrong. Please try again.');
      addToast({
        type: 'error',
        title: 'Subscription failed',
        message: 'Please try again later.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (variant === 'compact') {
    return (
      <div className={cn('relative', className)}>
        <AnimatePresence mode="wait">
          {!isSuccess ? (
            <motion.form
              key="form"
              onSubmit={handleSubmit}
              className="relative"
              initial={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <div className="relative group">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setError('');
                  }}
                  onFocus={() => setIsFocused(true)}
                  onBlur={() => setIsFocused(false)}
                  placeholder="Enter your email"
                  disabled={isSubmitting}
                  className={cn(
                    'w-full px-4 py-3 pr-32 bg-white/5 border rounded-lg',
                    'text-white placeholder-gray-500',
                    'focus:outline-none focus:ring-2 focus:ring-blue-500/50',
                    'transition-all duration-300',
                    error ? 'border-red-500/50' : 'border-white/10 focus:border-blue-500',
                    'disabled:opacity-50'
                  )}
                />
                
                <Button
                  type="submit"
                  variant="gradient"
                  size="sm"
                  disabled={isSubmitting}
                  className="absolute right-1 top-1 bottom-1 px-4"
                >
                  {isSubmitting ? 'Subscribing...' : 'Subscribe'}
                </Button>

                {/* Focus glow */}
                <motion.div
                  className="absolute inset-0 rounded-lg pointer-events-none"
                  initial={{ opacity: 0 }}
                  animate={{ 
                    opacity: isFocused ? 1 : 0,
                    boxShadow: isFocused ? '0 0 20px rgba(0, 102, 255, 0.2)' : '0 0 0px rgba(0, 102, 255, 0)',
                  }}
                  transition={{ duration: durations.base }}
                />
              </div>
              
              <AnimatePresence>
                {error && (
                  <motion.p
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute -bottom-6 left-0 text-xs text-red-400"
                  >
                    {error}
                  </motion.p>
                )}
              </AnimatePresence>
            </motion.form>
          ) : (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex items-center justify-center py-3 px-4 bg-green-500/10 border border-green-500/30 rounded-lg"
            >
              <CheckCircle className="w-5 h-5 text-green-400 mr-2" />
              <span className="text-green-400">Successfully subscribed!</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  if (variant === 'inline') {
    return (
      <form onSubmit={handleSubmit} className={cn('flex gap-2', className)}>
        <input
          type="email"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
            setError('');
          }}
          placeholder="your@email.com"
          disabled={isSubmitting}
          className={cn(
            'flex-1 px-4 py-2 bg-white/5 border rounded-lg',
            'text-white placeholder-gray-500',
            'focus:outline-none focus:ring-2 focus:ring-blue-500/50',
            'transition-all duration-300',
            error ? 'border-red-500/50' : 'border-white/10',
          )}
        />
        <Button
          type="submit"
          variant="gradient"
          size="md"
          disabled={isSubmitting}
        >
          <ArrowRight className="w-4 h-4" />
        </Button>
      </form>
    );
  }

  // Default variant
  return (
    <div className={cn('glass rounded-2xl p-8', className)}>
      <AnimatePresence mode="wait">
        {!isSuccess ? (
          <motion.div
            key="form"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 p-0.5">
                <div className="w-full h-full rounded-[10px] bg-black flex items-center justify-center">
                  <Mail className="w-6 h-6 text-white" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Stay Updated</h3>
                <p className="text-sm text-gray-400">Get the latest news and updates</p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setError('');
                  }}
                  onFocus={() => setIsFocused(true)}
                  onBlur={() => setIsFocused(false)}
                  placeholder="Enter your email address"
                  disabled={isSubmitting}
                  className={cn(
                    'w-full px-4 py-3 bg-white/5 border rounded-lg',
                    'text-white placeholder-gray-500',
                    'focus:outline-none focus:ring-2 focus:ring-blue-500/50',
                    'transition-all duration-300',
                    error ? 'border-red-500/50' : 'border-white/10 focus:border-blue-500',
                    'disabled:opacity-50'
                  )}
                />
                
                {/* Animated underline */}
                <motion.div
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-blue-500 to-cyan-500"
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: isFocused ? 1 : 0 }}
                  transition={{
                    duration: durations.base,
                    ease: easings.outExpo,
                  }}
                />
              </div>

              <AnimatePresence>
                {error && (
                  <motion.p
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="text-sm text-red-400"
                  >
                    {error}
                  </motion.p>
                )}
              </AnimatePresence>

              <Button
                type="submit"
                variant="gradient"
                size="lg"
                disabled={isSubmitting}
                className="w-full"
              >
                {isSubmitting ? (
                  'Subscribing...'
                ) : (
                  <>
                    Subscribe Now
                    <Sparkles className="ml-2 w-4 h-4" />
                  </>
                )}
              </Button>

              <p className="text-xs text-gray-500 text-center">
                We respect your privacy. Unsubscribe at any time.
              </p>
            </form>
          </motion.div>
        ) : (
          <motion.div
            key="success"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{
              duration: durations.base,
              ease: easings.spring,
            }}
            className="text-center py-8"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{
                delay: 0.2,
                duration: durations.slow,
                ease: easings.bounce,
              }}
              className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-green-500/20 to-emerald-500/20 flex items-center justify-center"
            >
              <CheckCircle className="w-10 h-10 text-green-400" />
            </motion.div>
            <h3 className="text-xl font-bold mb-2">Welcome to the Family!</h3>
            <p className="text-gray-400 text-sm">
              Check your inbox to confirm your subscription.
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}