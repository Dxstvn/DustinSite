'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import { cn } from '@/lib/utils';
import { durations, easings } from '@/lib/animations';

interface Testimonial {
  id: number;
  name: string;
  title: string;
  company: string;
  content: string;
  rating: number;
  avatar?: string;
  results?: string;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Sarah Chen",
    title: "CEO",
    company: "TechFlow Solutions",
    content: "Jaspire transformed our online presence completely. Our conversion rate increased by 340% in just 3 months, and our bounce rate dropped to under 15%. The attention to detail and strategic thinking exceeded all our expectations.",
    rating: 5,
    results: "340% conversion increase"
  },
  {
    id: 2,
    name: "Marcus Rodriguez",
    title: "Founder",
    company: "GreenScope Analytics",
    content: "The team at Jaspire doesn't just build websites—they build growth engines. Our organic traffic grew 250% and we're now ranking #1 for our primary keywords. ROI was positive within the first month.",
    rating: 5,
    results: "250% traffic growth"
  },
  {
    id: 3,
    name: "Emily Thompson",
    title: "VP Marketing",
    company: "CloudVault Systems",
    content: "Working with Jaspire was a game-changer. They delivered a complex web application ahead of schedule and under budget. The performance is incredible—page load times under 0.8 seconds consistently.",
    rating: 5,
    results: "Delivered early & under budget"
  },
  {
    id: 4,
    name: "David Kim",
    title: "Director of Growth",
    company: "FinanceForward",
    content: "Our new platform has generated over $2M in additional revenue since launch. The UX is intuitive, the backend is rock-solid, and the ongoing support is exceptional. Best investment we've made.",
    rating: 5,
    results: "$2M additional revenue"
  },
  {
    id: 5,
    name: "Lisa Park",
    title: "Head of Digital",
    company: "RetailEdge Co",
    content: "The redesign completely transformed our customer experience. Cart abandonment dropped by 60%, mobile conversions doubled, and customer satisfaction scores hit an all-time high of 4.9/5.",
    rating: 5,
    results: "60% reduction in cart abandonment"
  }
];

interface TestimonialCarouselProps {
  className?: string;
  autoPlay?: boolean;
  interval?: number;
}

export function TestimonialCarousel({
  className,
  autoPlay = true,
  interval = 5000
}: TestimonialCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(autoPlay);

  useEffect(() => {
    if (!isPlaying) return;

    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, interval);

    return () => clearInterval(timer);
  }, [isPlaying, interval]);

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const currentTestimonial = testimonials[currentIndex];

  return (
    <div 
      className={cn('relative max-w-4xl mx-auto', className)}
      onMouseEnter={() => setIsPlaying(false)}
      onMouseLeave={() => setIsPlaying(autoPlay)}
    >
      <div className="relative overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{
              duration: durations.base,
              ease: easings.outExpo,
            }}
            className="text-center"
          >
            {/* Quote Icon */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="flex justify-center mb-[var(--spacing-md)]"
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center">
                <Quote className="w-6 h-6 text-blue-400" />
              </div>
            </motion.div>

            {/* Rating */}
            <div className="flex justify-center gap-1 mb-[var(--spacing-md)]">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={cn(
                    'w-5 h-5',
                    i < currentTestimonial.rating
                      ? 'text-yellow-400 fill-current'
                      : 'text-gray-600'
                  )}
                />
              ))}
            </div>

            {/* Content */}
            <blockquote className="text-xl md:text-2xl text-white font-medium leading-relaxed mb-[var(--spacing-lg)] max-w-3xl mx-auto">
              "{currentTestimonial.content}"
            </blockquote>

            {/* Results Badge */}
            {currentTestimonial.results && (
              <div className="inline-flex items-center px-4 py-2 rounded-full bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30 mb-[var(--spacing-md)]">
                <span className="text-green-400 font-semibold text-sm">
                  {currentTestimonial.results}
                </span>
              </div>
            )}

            {/* Author */}
            <div className="flex flex-col items-center">
              {currentTestimonial.avatar ? (
                <img
                  src={currentTestimonial.avatar}
                  alt={currentTestimonial.name}
                  className="w-16 h-16 rounded-full mb-3 border-2 border-white/20"
                />
              ) : (
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center mb-3 border-2 border-white/20">
                  <span className="text-white font-bold text-lg">
                    {currentTestimonial.name.split(' ').map(n => n[0]).join('')}
                  </span>
                </div>
              )}
              
              <div className="text-center">
                <div className="text-white font-semibold text-lg">
                  {currentTestimonial.name}
                </div>
                <div className="text-gray-400 text-sm">
                  {currentTestimonial.title} at {currentTestimonial.company}
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Navigation Buttons */}
      <button
        onClick={goToPrevious}
        className="absolute left-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 transition-all duration-200 group"
        aria-label="Previous testimonial"
      >
        <ChevronLeft className="w-6 h-6 text-gray-400 group-hover:text-white transition-colors" />
      </button>

      <button
        onClick={goToNext}
        className="absolute right-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 transition-all duration-200 group"
        aria-label="Next testimonial"
      >
        <ChevronRight className="w-6 h-6 text-gray-400 group-hover:text-white transition-colors" />
      </button>

      {/* Dots Indicator */}
      <div className="flex justify-center gap-2 mt-[var(--spacing-lg)]">
        {testimonials.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={cn(
              'w-3 h-3 rounded-full transition-all duration-300',
              index === currentIndex
                ? 'bg-blue-500 scale-125'
                : 'bg-white/20 hover:bg-white/40'
            )}
            aria-label={`Go to testimonial ${index + 1}`}
          />
        ))}
      </div>

      {/* Progress Bar */}
      {isPlaying && (
        <div className="mt-4 w-full h-1 bg-white/10 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-blue-500 to-cyan-500"
            initial={{ width: '0%' }}
            animate={{ width: '100%' }}
            transition={{ duration: interval / 1000, ease: 'linear' }}
            key={currentIndex}
          />
        </div>
      )}
    </div>
  );
}