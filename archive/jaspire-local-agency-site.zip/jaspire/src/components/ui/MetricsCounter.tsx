'use client';

import { useEffect, useRef, useState } from 'react';
import { motion, useInView, useMotionValue, useSpring } from 'framer-motion';
import { TrendingUp, Users, Clock, Award } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Metric {
  id: string;
  value: number;
  suffix: string;
  prefix?: string;
  label: string;
  description: string;
  icon: React.ComponentType<any>;
  color: string;
  increment?: number;
}

const metrics: Metric[] = [
  {
    id: 'projects',
    value: 250,
    suffix: '+',
    label: 'Projects Delivered',
    description: 'Successful launches across industries',
    icon: Award,
    color: 'from-blue-500 to-cyan-500',
    increment: 5
  },
  {
    id: 'conversion',
    value: 340,
    suffix: '%',
    label: 'Avg. Conversion Increase',
    description: 'Improvement in client results',
    icon: TrendingUp,
    color: 'from-green-500 to-emerald-500',
    increment: 8
  },
  {
    id: 'clients',
    value: 500,
    suffix: '+',
    label: 'Happy Clients',
    description: 'Companies we\'ve transformed',
    icon: Users,
    color: 'from-purple-500 to-indigo-500',
    increment: 12
  },
  {
    id: 'delivery',
    value: 48,
    suffix: 'h',
    label: 'Fast Delivery',
    description: 'Average time to launch',
    icon: Clock,
    color: 'from-orange-500 to-red-500',
    increment: 1
  }
];

function AnimatedCounter({ 
  value, 
  duration = 2000,
  increment = 1 
}: { 
  value: number; 
  duration?: number;
  increment?: number;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-10%" });
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    if (!isInView) return;

    let startTime: number;
    const startValue = 0;
    const endValue = value;

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Use easeOutExpo for smooth animation
      const easeOutExpo = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      const currentValue = Math.floor(startValue + (endValue - startValue) * easeOutExpo);
      
      setDisplayValue(currentValue);

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [isInView, value, duration]);

  return <span ref={ref}>{displayValue}</span>;
}

interface MetricsCounterProps {
  className?: string;
  variant?: 'grid' | 'horizontal' | 'compact';
}

export function MetricsCounter({ 
  className,
  variant = 'grid' 
}: MetricsCounterProps) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-10%" });

  if (variant === 'horizontal') {
    return (
      <div ref={ref} className={cn('flex flex-wrap justify-center gap-8 md:gap-16', className)}>
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <motion.div
              key={metric.id}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: index * 0.15, duration: 0.6 }}
              className="text-center"
            >
              <div className="flex items-center justify-center gap-2 mb-2">
                <div className={cn('p-1 rounded-lg bg-gradient-to-r', metric.color)}>
                  <Icon className="w-4 h-4 text-white" />
                </div>
                <div className="text-2xl md:text-3xl font-bold text-white">
                  {metric.prefix}
                  <AnimatedCounter value={metric.value} increment={metric.increment} />
                  {metric.suffix}
                </div>
              </div>
              <p className="text-gray-400 text-sm">{metric.label}</p>
            </motion.div>
          );
        })}
      </div>
    );
  }

  if (variant === 'compact') {
    return (
      <div ref={ref} className={cn('grid grid-cols-2 md:grid-cols-4 gap-4', className)}>
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <motion.div
              key={metric.id}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              className="p-4 rounded-xl bg-white/3 border border-white/10 text-center hover:bg-white/5 transition-colors"
            >
              <div className={cn('w-8 h-8 mx-auto mb-2 p-1.5 rounded-lg bg-gradient-to-r', metric.color)}>
                <Icon className="w-full h-full text-white" />
              </div>
              <div className="text-xl font-bold text-white mb-1">
                {metric.prefix}
                <AnimatedCounter value={metric.value} increment={metric.increment} />
                {metric.suffix}
              </div>
              <p className="text-gray-400 text-xs">{metric.label}</p>
            </motion.div>
          );
        })}
      </div>
    );
  }

  // Grid variant (default)
  return (
    <div ref={ref} className={className}>
      <div className="text-center mb-[var(--spacing-2xl)]">
        <h3 className="text-2xl font-bold text-white mb-[var(--spacing-sm)]">
          Results That Speak for Themselves
        </h3>
        <p className="text-gray-400">
          Real numbers from real clients who chose to grow with Jaspire
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <motion.div
              key={metric.id}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: index * 0.1, duration: 0.8 }}
              className="group"
            >
              <div className="p-6 rounded-2xl bg-white/3 border border-white/10 hover:bg-white/5 hover:border-white/20 transition-all duration-300 text-center h-full">
                {/* Icon */}
                <div className={cn(
                  'w-16 h-16 mx-auto mb-4 p-0.5 rounded-xl bg-gradient-to-r',
                  metric.color
                )}>
                  <div className="w-full h-full rounded-[10px] bg-black flex items-center justify-center">
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                </div>

                {/* Value */}
                <div className="mb-3">
                  <div className={cn(
                    'text-4xl font-black bg-gradient-to-r bg-clip-text text-transparent',
                    metric.color
                  )}>
                    {metric.prefix}
                    <AnimatedCounter value={metric.value} increment={metric.increment} />
                    {metric.suffix}
                  </div>
                </div>

                {/* Label */}
                <h4 className="text-white font-semibold text-lg mb-2">
                  {metric.label}
                </h4>

                {/* Description */}
                <p className="text-gray-400 text-sm">
                  {metric.description}
                </p>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Bottom CTA */}
      <div className="mt-[var(--spacing-2xl)] text-center">
        <div className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/30">
          <TrendingUp className="w-5 h-5 text-blue-400" />
          <span className="text-white font-semibold">Your results could be next</span>
        </div>
      </div>
    </div>
  );
}