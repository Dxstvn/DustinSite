'use client';

import { useEffect } from 'react';
import { preloadCriticalImages } from '@/lib/image-preloader';

export function ImagePreloader() {
  useEffect(() => {
    // Start preloading critical images as soon as the component mounts
    preloadCriticalImages();
  }, []);

  // This component doesn't render anything
  return null;
}