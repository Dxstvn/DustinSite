'use client';

import { cn } from '@/lib/utils';

interface ContentShimmerProps {
  className?: string;
  isLoading?: boolean;
  children: React.ReactNode;
}

export function ContentShimmer({ 
  className = '', 
  isLoading = false,
  children 
}: ContentShimmerProps) {
  if (!isLoading) return <>{children}</>;

  return (
    <div className={cn('relative overflow-hidden', className)}>
      {/* Content with reduced opacity */}
      <div className="opacity-30">
        {children}
      </div>
      
      {/* Shimmer overlay */}
      <div className="absolute inset-0 -translate-x-full animate-shimmer bg-gradient-to-r from-transparent via-white/10 to-transparent" />
    </div>
  );
}

export function TextShimmer({ text, isLoading = false }: { text: string; isLoading?: boolean }) {
  if (!isLoading) return <>{text}</>;

  return (
    <span className="relative inline-block">
      <span className="opacity-30">{text}</span>
      <span className="absolute inset-0 -translate-x-full animate-shimmer bg-gradient-to-r from-transparent via-white/20 to-transparent" />
    </span>
  );
}