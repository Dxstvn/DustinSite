'use client';

import * as React from 'react';
import { cn } from '@/lib/utils';
import { type VariantProps, cva } from 'class-variance-authority';
import { motion } from 'framer-motion';
import { durations, easings } from '@/lib/animations';

const buttonVariants = cva(
  'relative inline-flex items-center justify-center rounded-xl font-semibold transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 focus-visible:ring-offset-black disabled:pointer-events-none disabled:opacity-50 overflow-hidden',
  {
    variants: {
      variant: {
        primary: 'bg-white text-black hover:bg-gray-100',
        secondary: 'bg-gray-900 text-white hover:bg-gray-800 border border-gray-800',
        outline: 'border border-gray-700 bg-transparent text-gray-300 hover:bg-white/5 hover:text-white hover:border-gray-600',
        ghost: 'hover:bg-white/5 hover:text-white text-gray-400',
        glass: 'glass text-white hover:bg-white/[0.08]',
        gradient: [
          'bg-gradient-to-r from-blue-600 to-cyan-600',
          'text-white',
          'shadow-lg',
          'hover:shadow-blue-500/25',
          'hover:from-blue-500',
          'hover:to-cyan-500',
        ].join(' '),
      },
      size: {
        sm: 'h-9 px-4 text-sm',
        md: 'h-11 px-6 text-sm',
        lg: 'h-12 px-8 text-base',
        xl: 'h-14 px-10 text-lg',
        icon: 'h-10 w-10',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'md',
    },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
  loading?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, loading, children, disabled, ...props }, ref) => {
    return (
      <motion.button
        whileHover={{ 
          scale: 1.02,
          transition: {
            duration: durations.fast,
            ease: easings.outExpo,
          }
        }}
        whileTap={{ 
          scale: 0.98,
          transition: {
            duration: durations.instant,
            ease: easings.out,
          }
        }}
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        disabled={disabled || loading}
        style={{
          transition: `all ${durations.base}s ${easings.outExpo.join(',')}`,
        }}
        {...props}
      >
        {/* Shimmer effect for gradient button */}
        {variant === 'gradient' && (
          <motion.div
            className="absolute inset-0 opacity-0 hover:opacity-100 transition-opacity duration-300"
            style={{
              background: 'linear-gradient(105deg, transparent 40%, rgba(255,255,255,0.3) 50%, transparent 60%)',
            }}
            animate={{
              x: ['-100%', '200%'],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              repeatDelay: 1,
              ease: 'linear',
            }}
          />
        )}
        
        {/* Button content */}
        <span className="relative z-10 flex items-center">
          {loading ? (
            <>
              <svg
                className="mr-2 h-4 w-4 animate-spin"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
              >
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                />
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                />
              </svg>
              Loading...
            </>
          ) : (
            children
          )}
        </span>
      </motion.button>
    );
  }
);

Button.displayName = 'Button';

export { Button, buttonVariants };