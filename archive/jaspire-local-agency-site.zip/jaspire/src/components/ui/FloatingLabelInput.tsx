'use client';

import { useState, useRef, InputHTMLAttributes, TextareaHTMLAttributes } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { AlertCircle, CheckCircle } from 'lucide-react';
import { durations, easings } from '@/lib/animations';

interface FloatingLabelInputProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
  success?: boolean;
  multiline?: false;
}

interface FloatingLabelTextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  error?: string;
  success?: boolean;
  multiline: true;
}

type Props = FloatingLabelInputProps | FloatingLabelTextareaProps;

export function FloatingLabelInput(props: Props) {
  const { label, error, success, className, multiline, ...inputProps } = props;
  const [isFocused, setIsFocused] = useState(false);
  const [hasValue, setHasValue] = useState(false);
  const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement>(null);

  const handleFocus = () => setIsFocused(true);
  const handleBlur = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setIsFocused(false);
    setHasValue(!!e.target.value);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setHasValue(!!e.target.value);
    if ('onChange' in inputProps) {
      inputProps.onChange?.(e as any);
    }
  };

  const isActive = isFocused || hasValue;

  const baseClasses = cn(
    'w-full px-4 pt-6 pb-2 text-white bg-white/5 border rounded-lg transition-all duration-300',
    'focus:outline-none focus:ring-2 focus:ring-blue-500/50',
    {
      'border-red-500/50 focus:border-red-500': error,
      'border-green-500/50 focus:border-green-500': success && !error,
      'border-white/10 focus:border-blue-500': !error && !success,
      'hover:bg-white/[0.07]': !error,
    },
    className
  );

  return (
    <div className="relative group">
      {/* Floating Label */}
      <motion.label
        htmlFor={inputProps.id}
        className={cn(
          'absolute left-4 pointer-events-none select-none transition-all',
          isActive ? 'text-xs text-gray-400' : 'text-base text-gray-500',
          error && 'text-red-400',
          success && !error && 'text-green-400'
        )}
        initial={false}
        animate={{
          y: isActive ? 8 : 24,
          scale: isActive ? 0.85 : 1,
          originX: 0,
        }}
        transition={{
          duration: durations.fast,
          ease: easings.outExpo,
        }}
      >
        {label}
        {inputProps.required && <span className="text-red-400 ml-1">*</span>}
      </motion.label>

      {/* Input Field */}
      {multiline ? (
        <textarea
          ref={inputRef as React.RefObject<HTMLTextAreaElement>}
          className={baseClasses}
          onFocus={handleFocus}
          onBlur={handleBlur}
          onChange={handleChange}
          {...(inputProps as TextareaHTMLAttributes<HTMLTextAreaElement>)}
        />
      ) : (
        <input
          ref={inputRef as React.RefObject<HTMLInputElement>}
          className={baseClasses}
          onFocus={handleFocus}
          onBlur={handleBlur}
          onChange={handleChange}
          {...(inputProps as InputHTMLAttributes<HTMLInputElement>)}
        />
      )}

      {/* Focus Line */}
      <motion.div
        className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-blue-500 to-cyan-500"
        initial={{ scaleX: 0 }}
        animate={{ scaleX: isFocused ? 1 : 0 }}
        transition={{
          duration: durations.base,
          ease: easings.outExpo,
        }}
      />

      {/* Error/Success Message */}
      <AnimatePresence mode="wait">
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: durations.fast }}
            className="absolute -bottom-6 left-0 flex items-center gap-1 text-xs text-red-400"
          >
            <AlertCircle className="w-3 h-3" />
            {error}
          </motion.div>
        )}
        {success && !error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: durations.fast }}
            className="absolute -bottom-6 right-0"
          >
            <CheckCircle className="w-4 h-4 text-green-400" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Glow Effect on Focus */}
      <motion.div
        className="absolute inset-0 rounded-lg pointer-events-none"
        initial={{ opacity: 0 }}
        animate={{ 
          opacity: isFocused ? 1 : 0,
          boxShadow: isFocused ? '0 0 20px rgba(0, 102, 255, 0.2)' : '0 0 0px rgba(0, 102, 255, 0)',
        }}
        transition={{
          duration: durations.base,
          ease: easings.out,
        }}
      />
    </div>
  );
}