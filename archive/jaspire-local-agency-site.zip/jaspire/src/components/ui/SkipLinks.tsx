'use client';

import { ACCESSIBILITY_CONFIG } from '@/lib/accessibility';

export function SkipLinks() {
  return (
    <nav aria-label="Skip links" className="sr-only focus-within:not-sr-only">
      {ACCESSIBILITY_CONFIG.skipLinks.map((link, index) => (
        <a
          key={index}
          href={link.href}
          className="absolute top-4 left-4 z-50 px-4 py-2 bg-blue-600 text-white rounded focus:outline-none focus:ring-2 focus:ring-blue-300"
        >
          {link.text}
        </a>
      ))}
    </nav>
  );
}