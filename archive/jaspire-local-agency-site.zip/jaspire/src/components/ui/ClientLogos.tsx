'use client';

import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { durations, easings } from '@/lib/animations';
import { OptimizedImage } from './OptimizedImage';

interface ClientLogo {
  name: string;
  logo: string;
  width?: number;
  height?: number;
}

const clients: ClientLogo[] = [
  {
    name: "TechFlow Solutions",
    logo: "/logos/techflow.svg",
    width: 140,
    height: 40
  },
  {
    name: "GreenScope Analytics",
    logo: "/logos/greenscope.svg", 
    width: 160,
    height: 35
  },
  {
    name: "CloudVault Systems",
    logo: "/logos/cloudvault.svg",
    width: 150,
    height: 42
  },
  {
    name: "FinanceForward",
    logo: "/logos/financeforward.svg",
    width: 145,
    height: 38
  },
  {
    name: "RetailEdge Co",
    logo: "/logos/retailedge.svg",
    width: 135,
    height: 40
  },
  {
    name: "DataSync Pro",
    logo: "/logos/datasync.svg",
    width: 155,
    height: 36
  },
  {
    name: "NextGen Motors",
    logo: "/logos/nextgen.svg",
    width: 148,
    height: 41
  },
  {
    name: "HealthTech Plus",
    logo: "/logos/healthtech.svg",
    width: 142,
    height: 39
  }
];

// Fallback text logos for when SVGs aren't available
const textLogos: Array<{ name: string; color: string }> = [
  { name: "TechFlow", color: "from-blue-500 to-cyan-500" },
  { name: "GreenScope", color: "from-green-500 to-emerald-500" },
  { name: "CloudVault", color: "from-purple-500 to-indigo-500" },
  { name: "FinanceForward", color: "from-yellow-500 to-orange-500" },
  { name: "RetailEdge", color: "from-pink-500 to-rose-500" },
  { name: "DataSync", color: "from-teal-500 to-cyan-500" },
  { name: "NextGen", color: "from-indigo-500 to-purple-500" },
  { name: "HealthTech", color: "from-emerald-500 to-green-500" }
];

interface ClientLogosProps {
  className?: string;
  variant?: 'grid' | 'marquee' | 'simple' | 'images';
  showTitle?: boolean;
}

export function ClientLogos({ 
  className,
  variant = 'grid',
  showTitle = true 
}: ClientLogosProps) {
  
  // Images variant with OptimizedImage
  if (variant === 'images') {
    return (
      <div className={className}>
        {showTitle && (
          <div className="text-center mb-[var(--spacing-2xl)]">
            <h3 className="text-2xl font-bold text-white mb-[var(--spacing-sm)]">
              Trusted by Industry Leaders
            </h3>
            <p className="text-gray-400">
              Join 500+ companies that chose Jaspire for their digital transformation
            </p>
          </div>
        )}
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center justify-items-center">
          {clients.map((client, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              whileHover={{ scale: 1.05 }}
              transition={{ 
                delay: index * 0.1,
                duration: durations.base,
                ease: easings.outExpo 
              }}
              viewport={{ once: true }}
              className="group cursor-pointer"
            >
              <div className="p-6 rounded-lg bg-white/3 hover:bg-white/8 border border-white/10 hover:border-white/20 transition-all duration-300">
                <OptimizedImage
                  src={client.logo}
                  alt={`${client.name} logo`}
                  width={client.width || 150}
                  height={client.height || 40}
                  className="filter brightness-75 group-hover:brightness-100 transition-all duration-300"
                  configType="logos"
                  fallbackSrc={`data:image/svg+xml,${encodeURIComponent(`
                    <svg width="${client.width || 150}" height="${client.height || 40}" xmlns="http://www.w3.org/2000/svg">
                      <rect width="100%" height="100%" fill="none"/>
                      <text x="50%" y="50%" text-anchor="middle" dy="0.35em" fill="#6366f1" font-family="Arial" font-weight="bold" font-size="14">${client.name}</text>
                    </svg>
                  `)}`}
                  priority={index < 4} // Preload first 4 logos
                />
              </div>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-[var(--spacing-2xl)] text-center">
          <div className="inline-flex items-center gap-4 px-6 py-3 rounded-full bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/20">
            <span className="text-blue-400 font-semibold">500+</span>
            <span className="text-gray-400">companies trust Jaspire</span>
            <span className="text-green-400 font-semibold">98%</span>
            <span className="text-gray-400">client retention rate</span>
          </div>
        </div>
      </div>
    );
  }
  
  if (variant === 'marquee') {
    return (
      <div className={cn('overflow-hidden', className)}>
        {showTitle && (
          <div className="text-center mb-[var(--spacing-2xl)]">
            <h3 className="text-2xl font-bold text-white mb-[var(--spacing-sm)]">
              Trusted by Industry Leaders
            </h3>
            <p className="text-gray-400">
              Join 500+ companies that chose Jaspire for their digital transformation
            </p>
          </div>
        )}
        
        <div className="relative">
          {/* Gradient overlays */}
          <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-black to-transparent z-10" />
          <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-black to-transparent z-10" />
          
          <div className="flex">
            {/* First set */}
            <motion.div
              className="flex gap-12 items-center"
              animate={{ x: ['0%', '-100%'] }}
              transition={{
                duration: 30,
                repeat: Infinity,
                ease: 'linear'
              }}
            >
              {textLogos.map((client, index) => (
                <div
                  key={index}
                  className="flex-shrink-0 px-6"
                >
                  <div className={cn(
                    'text-2xl font-bold bg-gradient-to-r bg-clip-text text-transparent opacity-60 hover:opacity-100 transition-opacity',
                    client.color
                  )}>
                    {client.name}
                  </div>
                </div>
              ))}
            </motion.div>
            
            {/* Duplicate set for seamless loop */}
            <motion.div
              className="flex gap-12 items-center"
              animate={{ x: ['0%', '-100%'] }}
              transition={{
                duration: 30,
                repeat: Infinity,
                ease: 'linear'
              }}
            >
              {textLogos.map((client, index) => (
                <div
                  key={`duplicate-${index}`}
                  className="flex-shrink-0 px-6"
                >
                  <div className={cn(
                    'text-2xl font-bold bg-gradient-to-r bg-clip-text text-transparent opacity-60 hover:opacity-100 transition-opacity',
                    client.color
                  )}>
                    {client.name}
                  </div>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </div>
    );
  }

  if (variant === 'simple') {
    return (
      <div className={cn('text-center', className)}>
        <p className="text-gray-500 text-sm uppercase tracking-wider mb-[var(--spacing-lg)]">
          Trusted by
        </p>
        <div className="flex flex-wrap justify-center items-center gap-8">
          {textLogos.slice(0, 5).map((client, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
              className={cn(
                'text-lg font-semibold bg-gradient-to-r bg-clip-text text-transparent',
                client.color
              )}
            >
              {client.name}
            </motion.div>
          ))}
        </div>
      </div>
    );
  }

  // Grid variant (default)
  return (
    <div className={className}>
      {showTitle && (
        <div className="text-center mb-[var(--spacing-2xl)]">
          <h3 className="text-2xl font-bold text-white mb-[var(--spacing-sm)]">
            Trusted by Industry Leaders
          </h3>
          <p className="text-gray-400">
            Join 500+ companies that chose Jaspire for their digital transformation
          </p>
        </div>
      )}
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center justify-items-center">
        {textLogos.map((client, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            whileHover={{ scale: 1.1 }}
            transition={{ 
              delay: index * 0.1,
              duration: durations.base,
              ease: easings.outExpo 
            }}
            viewport={{ once: true }}
            className="group cursor-pointer"
          >
            <div className="p-4 rounded-lg bg-white/3 hover:bg-white/5 border border-white/10 hover:border-white/20 transition-all duration-300">
              <div className={cn(
                'text-xl font-semibold bg-gradient-to-r bg-clip-text text-transparent group-hover:scale-105 transition-transform',
                client.color
              )}>
                {client.name}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
      
      {/* Stats below logos */}
      <div className="mt-[var(--spacing-2xl)] text-center">
        <div className="inline-flex items-center gap-4 px-6 py-3 rounded-full bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/20">
          <span className="text-blue-400 font-semibold">500+</span>
          <span className="text-gray-400">companies trust Jaspire</span>
          <span className="text-green-400 font-semibold">98%</span>
          <span className="text-gray-400">client retention rate</span>
        </div>
      </div>
    </div>
  );
}