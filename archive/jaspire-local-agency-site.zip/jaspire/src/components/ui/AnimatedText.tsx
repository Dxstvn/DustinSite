'use client';

import { motion, Variants } from 'framer-motion';
import { ReactNode, useMemo } from 'react';
import { textAnimations, splitTextToArray } from '@/lib/text-animations';
import { cn } from '@/lib/utils';

interface AnimatedTextProps {
  children: string;
  className?: string;
  animation?: keyof typeof textAnimations | Variants;
  delay?: number;
  duration?: number;
  stagger?: number;
  split?: 'letters' | 'words' | 'none';
  as?: 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6' | 'p' | 'span' | 'div';
}

export function AnimatedText({
  children,
  className,
  animation = 'fadeInUp',
  delay = 0,
  duration,
  stagger,
  split = 'none',
  as: Component = 'div',
}: AnimatedTextProps) {
  const animationVariant = useMemo(() => {
    if (typeof animation === 'string') {
      return textAnimations[animation];
    }
    return animation;
  }, [animation]);

  // Handle split text animations
  if (split !== 'none') {
    const textArray = splitTextToArray(children, split);
    const splitContent = textArray.map((char, i) => (
      <span key={i} className="inline-block">
        {char === '\u00A0' ? ' ' : char}
      </span>
    ));
    const containerVariants = {
      initial: { opacity: 0 },
      animate: {
        opacity: 1,
        transition: {
          staggerChildren: stagger || (split === 'letters' ? 0.03 : 0.08),
          delayChildren: delay,
        },
      },
    };

    const childVariants = {
      initial: {
        opacity: 0,
        y: 20,
        rotateX: -90,
      },
      animate: {
        opacity: 1,
        y: 0,
        rotateX: 0,
        transition: {
          duration: duration || 0.5,
          ease: [0.22, 1, 0.36, 1],
        },
      },
    };

    return (
      <Component className={cn('relative', className)}>
        <motion.span
          variants={containerVariants}
          initial="initial"
          animate="animate"
          className="inline-block"
        >
          {splitContent.map((item, index) => (
            <motion.span
              key={index}
              variants={childVariants}
              className="inline-block origin-bottom"
              style={{ transformStyle: 'preserve-3d' }}
            >
              {item}
            </motion.span>
          ))}
        </motion.span>
      </Component>
    );
  }

  // Regular animation without splitting
  const MotionComponent = motion[Component as keyof typeof motion] as any;

  return (
    <MotionComponent
      className={className}
      initial={animationVariant.initial}
      animate={animationVariant.animate}
      transition={{
        delay,
        duration,
        ...animationVariant.animate?.transition,
      }}
    >
      {children}
    </MotionComponent>
  );
}

// Animated heading with automatic styling
interface AnimatedHeadingProps extends Omit<AnimatedTextProps, 'as'> {
  level?: 1 | 2 | 3 | 4 | 5 | 6;
}

export function AnimatedHeading({
  level = 2,
  className,
  children,
  ...props
}: AnimatedHeadingProps) {
  const headingClasses = {
    1: 'text-display',
    2: 'text-title',
    3: 'text-headline',
    4: 'text-subheading',
    5: 'text-xl font-semibold',
    6: 'text-lg font-semibold',
  };

  return (
    <AnimatedText
      as={`h${level}` as any}
      className={cn(headingClasses[level], className)}
      animation="fadeInUp"
      {...props}
    >
      {children}
    </AnimatedText>
  );
}

// Animated paragraph with automatic styling
export function AnimatedParagraph({
  className,
  variant = 'body',
  ...props
}: AnimatedTextProps & { variant?: 'body' | 'body-large' | 'small' | 'caption' }) {
  const variantClasses = {
    'body': 'text-body',
    'body-large': 'text-body-large',
    'small': 'text-small',
    'caption': 'text-caption',
  };

  return (
    <AnimatedText
      as="p"
      className={cn(variantClasses[variant], className)}
      animation="fadeInUp"
      {...props}
    />
  );
}

// Gradient animated text
export function GradientText({
  children,
  className,
  animated = true,
}: {
  children: string;
  className?: string;
  animated?: boolean;
}) {
  if (animated) {
    return (
      <motion.span
        className={cn(
          'inline-block bg-gradient-to-r from-blue-400 via-cyan-400 to-blue-400 bg-clip-text text-transparent',
          'bg-[length:200%_auto]',
          className
        )}
        animate={{
          backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
        }}
        transition={{
          duration: 5,
          ease: 'linear',
          repeat: Infinity,
        }}
      >
        {children}
      </motion.span>
    );
  }

  return (
    <span className={cn('gradient-text', className)}>
      {children}
    </span>
  );
}

// Glitch text effect
export function GlitchText({
  children,
  className,
}: {
  children: string;
  className?: string;
}) {
  return (
    <div className={cn('relative inline-block', className)}>
      <motion.span
        className="relative z-10"
        animate={{
          x: [0, -2, 2, -1, 1, 0],
          textShadow: [
            '0 0 0 transparent',
            '2px 2px 0 #ff00ff, -2px -2px 0 #00ffff',
            '-2px 2px 0 #ff00ff, 2px -2px 0 #00ffff',
            '0 0 0 transparent',
          ],
        }}
        transition={{
          duration: 0.5,
          repeat: Infinity,
          repeatDelay: 3,
        }}
      >
        {children}
      </motion.span>
    </div>
  );
}