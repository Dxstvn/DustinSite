'use client';

import { useRef, MouseEvent } from 'react';
import { motion } from 'framer-motion';

interface InteractiveCardProps {
  children: React.ReactNode;
  className?: string;
}

export function InteractiveCard({ children, className = '' }: InteractiveCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;

    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rotateX = (y - centerY) / 10;
    const rotateY = (centerX - x) / 10;

    cardRef.current.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.05, 1.05, 1.05)`;
    
    // Update gradient position
    const gradient = cardRef.current.querySelector('.gradient-overlay') as HTMLElement;
    if (gradient) {
      gradient.style.background = `radial-gradient(circle at ${x}px ${y}px, rgba(0, 102, 255, 0.3), transparent 50%)`;
    }
  };

  const handleMouseLeave = () => {
    if (!cardRef.current) return;
    cardRef.current.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale3d(1, 1, 1)';
    
    const gradient = cardRef.current.querySelector('.gradient-overlay') as HTMLElement;
    if (gradient) {
      gradient.style.background = 'transparent';
    }
  };

  return (
    <motion.div
      ref={cardRef}
      className={`relative overflow-hidden transition-transform duration-200 ease-out ${className}`}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      style={{ transformStyle: 'preserve-3d' }}
    >
      <div className="gradient-overlay absolute inset-0 pointer-events-none transition-all duration-300 z-10" />
      {children}
    </motion.div>
  );
}