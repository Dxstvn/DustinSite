'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FloatingLabelInput } from './FloatingLabelInput';
import { Button } from './Button';
import { useToast } from './Toast';
import { Send, Loader2, CheckCircle } from 'lucide-react';
import { durations, easings, variants } from '@/lib/animations';

interface FormData {
  name: string;
  email: string;
  company: string;
  phone: string;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  company?: string;
  phone?: string;
  message?: string;
}

export function ContactForm() {
  const { addToast } = useToast();
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    company: '',
    phone: '',
    message: '',
  });
  
  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Invalid email address';
    }
    
    if (!formData.message.trim()) {
      newErrors.message = 'Message is required';
    } else if (formData.message.length < 10) {
      newErrors.message = 'Message must be at least 10 characters';
    }
    
    if (formData.phone && !/^[\d\s\-\+\(\)]+$/.test(formData.phone)) {
      newErrors.phone = 'Invalid phone number';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      addToast({
        type: 'error',
        title: 'Validation Error',
        message: 'Please fix the errors in the form',
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setIsSuccess(true);
      addToast({
        type: 'success',
        title: 'Message Sent!',
        message: 'We\'ll get back to you within 24 hours.',
      });
      
      // Reset form after delay
      setTimeout(() => {
        setFormData({
          name: '',
          email: '',
          company: '',
          phone: '',
          message: '',
        });
        setIsSuccess(false);
      }, 3000);
    } catch (error) {
      addToast({
        type: 'error',
        title: 'Error',
        message: 'Failed to send message. Please try again.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (field: keyof FormData) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData(prev => ({ ...prev, [field]: e.target.value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  return (
    <motion.div
      initial="initial"
      animate="animate"
      variants={variants.container}
      className="w-full max-w-2xl mx-auto"
    >
      <AnimatePresence mode="wait">
        {!isSuccess ? (
          <motion.form
            key="form"
            onSubmit={handleSubmit}
            className="space-y-[var(--spacing-lg)]"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: durations.base }}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-[var(--spacing-lg)]">
              <motion.div variants={variants.item}>
                <FloatingLabelInput
                  id="name"
                  label="Your Name"
                  type="text"
                  required
                  value={formData.name}
                  onChange={handleChange('name')}
                  error={errors.name}
                  disabled={isSubmitting}
                />
              </motion.div>
              
              <motion.div variants={variants.item}>
                <FloatingLabelInput
                  id="email"
                  label="Email Address"
                  type="email"
                  required
                  value={formData.email}
                  onChange={handleChange('email')}
                  error={errors.email}
                  disabled={isSubmitting}
                />
              </motion.div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-[var(--spacing-lg)]">
              <motion.div variants={variants.item}>
                <FloatingLabelInput
                  id="company"
                  label="Company"
                  type="text"
                  value={formData.company}
                  onChange={handleChange('company')}
                  error={errors.company}
                  disabled={isSubmitting}
                />
              </motion.div>
              
              <motion.div variants={variants.item}>
                <FloatingLabelInput
                  id="phone"
                  label="Phone Number"
                  type="tel"
                  value={formData.phone}
                  onChange={handleChange('phone')}
                  error={errors.phone}
                  disabled={isSubmitting}
                />
              </motion.div>
            </div>
            
            <motion.div variants={variants.item}>
              <FloatingLabelInput
                id="message"
                label="Your Message"
                multiline
                rows={6}
                required
                value={formData.message}
                onChange={handleChange('message')}
                error={errors.message}
                disabled={isSubmitting}
              />
            </motion.div>
            
            <motion.div 
              variants={variants.item}
              className="flex justify-center"
            >
              <Button
                type="submit"
                variant="gradient"
                size="lg"
                disabled={isSubmitting}
                className="min-w-[200px] h-[56px]"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 w-5 h-5 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 w-5 h-5" />
                    Send Message
                  </>
                )}
              </Button>
            </motion.div>
          </motion.form>
        ) : (
          <motion.div
            key="success"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{
              duration: durations.base,
              ease: easings.spring,
            }}
            className="text-center py-[var(--spacing-3xl)]"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{
                delay: 0.2,
                duration: durations.slow,
                ease: easings.spring,
              }}
              className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-green-500/20 to-emerald-500/20 flex items-center justify-center"
            >
              <CheckCircle className="w-12 h-12 text-green-400" />
            </motion.div>
            <motion.h3
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-2xl font-bold mb-2"
            >
              Message Sent Successfully!
            </motion.h3>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-gray-400"
            >
              We'll get back to you within 24 hours.
            </motion.p>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}