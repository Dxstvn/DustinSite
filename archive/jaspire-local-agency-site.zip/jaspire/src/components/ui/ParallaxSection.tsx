'use client';

import { useRef, ReactNode } from 'react';
import { motion, useScroll, useTransform, MotionValue } from 'framer-motion';
import { cn } from '@/lib/utils';

interface ParallaxSectionProps {
  children: ReactNode;
  className?: string;
  offset?: number;
  speed?: number;
}

export function ParallaxSection({
  children,
  className,
  offset = 0,
  speed = 0.5,
}: ParallaxSectionProps) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  });

  const y = useTransform(scrollYProgress, [0, 1], [offset - 100 * speed, offset + 100 * speed]);
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0, 1, 1, 0]);

  return (
    <motion.div
      ref={ref}
      style={{ y, opacity }}
      className={cn('relative', className)}
    >
      {children}
    </motion.div>
  );
}

interface ParallaxImageProps {
  src: string;
  alt: string;
  className?: string;
  speed?: number;
}

export function ParallaxImage({
  src,
  alt,
  className,
  speed = 0.3,
}: ParallaxImageProps) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  });

  const y = useTransform(scrollYProgress, [0, 1], ['0%', `${speed * 100}%`]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [1.2, 1.1, 1]);

  return (
    <div ref={ref} className={cn('relative overflow-hidden', className)}>
      <motion.img
        src={src}
        alt={alt}
        style={{ y, scale }}
        className="w-full h-full object-cover"
      />
    </div>
  );
}

interface ParallaxTextProps {
  children: ReactNode;
  className?: string;
  speed?: number;
  direction?: 'up' | 'down' | 'left' | 'right';
}

export function ParallaxText({
  children,
  className,
  speed = 0.5,
  direction = 'up',
}: ParallaxTextProps) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  });

  const transforms: Record<string, MotionValue<string | number>> = {
    up: useTransform(scrollYProgress, [0, 1], [100 * speed, -100 * speed]),
    down: useTransform(scrollYProgress, [0, 1], [-100 * speed, 100 * speed]),
    left: useTransform(scrollYProgress, [0, 1], [100 * speed, -100 * speed]),
    right: useTransform(scrollYProgress, [0, 1], [-100 * speed, 100 * speed]),
  };

  const transform = transforms[direction];
  const isHorizontal = direction === 'left' || direction === 'right';

  return (
    <motion.div
      ref={ref}
      style={{
        [isHorizontal ? 'x' : 'y']: transform,
      }}
      className={cn('relative', className)}
    >
      {children}
    </motion.div>
  );
}

// Layered parallax for depth effect
interface LayeredParallaxProps {
  layers: Array<{
    content: ReactNode;
    speed: number;
    className?: string;
  }>;
  className?: string;
}

export function LayeredParallax({ layers, className }: LayeredParallaxProps) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  });

  return (
    <div ref={ref} className={cn('relative', className)}>
      {layers.map((layer, index) => {
        const y = useTransform(
          scrollYProgress,
          [0, 1],
          [`${layer.speed * 100}px`, `-${layer.speed * 100}px`]
        );

        return (
          <motion.div
            key={index}
            style={{ y }}
            className={cn('absolute inset-0', layer.className)}
          >
            {layer.content}
          </motion.div>
        );
      })}
    </div>
  );
}

// Reveal on scroll with parallax
interface ParallaxRevealProps {
  children: ReactNode;
  className?: string;
  threshold?: number;
}

export function ParallaxReveal({
  children,
  className,
  threshold = 0.2,
}: ParallaxRevealProps) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'center center'],
  });

  const opacity = useTransform(scrollYProgress, [0, threshold], [0, 1]);
  const y = useTransform(scrollYProgress, [0, threshold], [50, 0]);
  const scale = useTransform(scrollYProgress, [0, threshold], [0.9, 1]);

  return (
    <motion.div
      ref={ref}
      style={{ opacity, y, scale }}
      className={cn('relative', className)}
    >
      {children}
    </motion.div>
  );
}