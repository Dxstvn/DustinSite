'use client';

import { cn } from '@/lib/utils';

interface LoadingSkeletonProps {
  className?: string;
  variant?: 'text' | 'card' | 'avatar' | 'button';
  lines?: number;
}

export function LoadingSkeleton({ 
  className = '', 
  variant = 'text',
  lines = 1 
}: LoadingSkeletonProps) {
  const baseClass = 'animate-pulse bg-gradient-to-r from-gray-800 via-gray-700 to-gray-800 background-animate rounded';
  
  const variants = {
    text: 'h-4 w-full',
    card: 'h-64 w-full rounded-xl',
    avatar: 'h-12 w-12 rounded-full',
    button: 'h-10 w-32 rounded-lg',
  };

  if (variant === 'text' && lines > 1) {
    return (
      <div className={cn('space-y-2', className)}>
        {Array.from({ length: lines }).map((_, i) => (
          <div
            key={i}
            className={cn(
              baseClass,
              variants.text,
              i === lines - 1 && 'w-3/4'
            )}
          />
        ))}
      </div>
    );
  }

  return (
    <div className={cn(baseClass, variants[variant], className)} />
  );
}

export function CardSkeleton() {
  return (
    <div className="glass rounded-xl p-6 space-y-4">
      <LoadingSkeleton variant="avatar" />
      <LoadingSkeleton variant="text" lines={2} />
      <LoadingSkeleton variant="button" />
    </div>
  );
}

export function PageSkeleton() {
  return (
    <div className="min-h-screen bg-black p-6">
      <div className="container mx-auto space-y-8">
        {/* Header skeleton */}
        <div className="space-y-4 text-center max-w-3xl mx-auto">
          <LoadingSkeleton className="h-12 w-2/3 mx-auto" />
          <LoadingSkeleton variant="text" lines={3} />
        </div>
        
        {/* Cards grid skeleton */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      </div>
    </div>
  );
}