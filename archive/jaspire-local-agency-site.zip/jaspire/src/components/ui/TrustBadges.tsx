'use client';

import { motion } from 'framer-motion';
import { Shield, Award, Clock, Users, Zap, Globe } from 'lucide-react';
import { cn } from '@/lib/utils';
import { durations, easings } from '@/lib/animations';

interface TrustBadge {
  id: string;
  icon: React.ComponentType<any>;
  title: string;
  subtitle: string;
  color: string;
}

const trustBadges: TrustBadge[] = [
  {
    id: 'security',
    icon: Shield,
    title: 'SOC 2 Certified',
    subtitle: 'Enterprise Security',
    color: 'from-green-500 to-emerald-500'
  },
  {
    id: 'quality',
    icon: Award,
    title: '99.9% Uptime',
    subtitle: 'Guaranteed SLA',
    color: 'from-blue-500 to-cyan-500'
  },
  {
    id: 'speed',
    icon: Zap,
    title: '<0.2s Load Time',
    subtitle: 'Lightning Fast',
    color: 'from-yellow-500 to-orange-500'
  },
  {
    id: 'support',
    icon: Clock,
    title: '24/7 Support',
    subtitle: 'Always Available',
    color: 'from-purple-500 to-indigo-500'
  },
  {
    id: 'clients',
    icon: Users,
    title: '500+ Clients',
    subtitle: 'Trusted Worldwide',
    color: 'from-pink-500 to-rose-500'
  },
  {
    id: 'global',
    icon: Globe,
    title: 'Global CDN',
    subtitle: '6 Continents',
    color: 'from-teal-500 to-cyan-500'
  }
];

interface TrustBadgesProps {
  className?: string;
  variant?: 'grid' | 'horizontal' | 'compact';
  showTitle?: boolean;
}

export function TrustBadges({
  className,
  variant = 'grid',
  showTitle = true
}: TrustBadgesProps) {
  
  if (variant === 'horizontal') {
    return (
      <div className={cn('overflow-hidden', className)}>
        {showTitle && (
          <div className="text-center mb-[var(--spacing-lg)]">
            <h3 className="text-lg font-semibold text-white mb-2">
              Enterprise-Grade Reliability
            </h3>
          </div>
        )}
        
        <div className="flex flex-wrap justify-center gap-4">
          {trustBadges.map((badge, index) => {
            const Icon = badge.icon;
            return (
              <motion.div
                key={badge.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10"
              >
                <div className={cn('w-6 h-6 p-1 rounded bg-gradient-to-r', badge.color)}>
                  <Icon className="w-full h-full text-white" />
                </div>
                <div>
                  <div className="text-white font-semibold text-sm">{badge.title}</div>
                  <div className="text-gray-400 text-xs">{badge.subtitle}</div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    );
  }

  if (variant === 'compact') {
    return (
      <div className={cn('grid grid-cols-2 md:grid-cols-3 gap-3', className)}>
        {trustBadges.map((badge, index) => {
          const Icon = badge.icon;
          return (
            <motion.div
              key={badge.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              whileHover={{ scale: 1.02 }}
              transition={{ delay: index * 0.05 }}
              viewport={{ once: true }}
              className="p-3 rounded-lg bg-white/3 border border-white/10 hover:bg-white/5 transition-all text-center"
            >
              <div className={cn('w-8 h-8 mx-auto mb-2 p-1.5 rounded bg-gradient-to-r', badge.color)}>
                <Icon className="w-full h-full text-white" />
              </div>
              <div className="text-white font-semibold text-xs mb-1">{badge.title}</div>
              <div className="text-gray-400 text-xs">{badge.subtitle}</div>
            </motion.div>
          );
        })}
      </div>
    );
  }

  // Grid variant (default)
  return (
    <div className={className}>
      {showTitle && (
        <div className="text-center mb-[var(--spacing-2xl)]">
          <h3 className="text-2xl font-bold text-white mb-[var(--spacing-sm)]">
            Enterprise-Grade Security & Reliability
          </h3>
          <p className="text-gray-400">
            Your business deserves the highest standards of security and performance
          </p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {trustBadges.map((badge, index) => {
          const Icon = badge.icon;
          return (
            <motion.div
              key={badge.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              whileHover={{ 
                y: -4,
                transition: { duration: durations.fast, ease: easings.outExpo }
              }}
              transition={{ 
                delay: index * 0.1,
                duration: durations.base,
                ease: easings.outExpo 
              }}
              viewport={{ once: true }}
              className="group cursor-pointer"
            >
              <div className="p-6 rounded-xl bg-white/3 border border-white/10 hover:bg-white/5 hover:border-white/20 transition-all duration-300 text-center h-full">
                {/* Icon */}
                <div className={cn(
                  'w-14 h-14 mx-auto mb-4 p-0.5 rounded-xl bg-gradient-to-r',
                  badge.color
                )}>
                  <div className="w-full h-full rounded-[10px] bg-black flex items-center justify-center">
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                </div>

                {/* Content */}
                <h4 className="text-white font-bold text-lg mb-1 group-hover:text-blue-200 transition-colors">
                  {badge.title}
                </h4>
                <p className="text-gray-400 text-sm">
                  {badge.subtitle}
                </p>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Additional Trust Indicators */}
      <div className="mt-[var(--spacing-2xl)]">
        <div className="flex flex-wrap justify-center gap-8 text-center">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="text-gray-400 text-sm">GDPR Compliant</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
            <span className="text-gray-400 text-sm">ISO 27001 Certified</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
            <span className="text-gray-400 text-sm">PCI DSS Level 1</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
            <span className="text-gray-400 text-sm">99.99% SLA</span>
          </div>
        </div>
      </div>
    </div>
  );
}