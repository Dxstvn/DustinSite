'use client';

import { useRef, useEffect, ReactNode, useState } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { cn } from '@/lib/utils';

interface MagneticEffectProps {
  children: ReactNode;
  className?: string;
  strength?: number;
  disabled?: boolean;
}

export function MagneticEffect({
  children,
  className,
  strength = 0.5,
  disabled = false,
}: MagneticEffectProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  
  const springConfig = { damping: 15, stiffness: 150 };
  const xSpring = useSpring(x, springConfig);
  const ySpring = useSpring(y, springConfig);

  useEffect(() => {
    if (disabled) return;

    const handleMouseMove = (e: MouseEvent) => {
      if (!ref.current || !isHovered) return;
      
      const rect = ref.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      
      const distanceX = e.clientX - centerX;
      const distanceY = e.clientY - centerY;
      
      x.set(distanceX * strength);
      y.set(distanceY * strength);
    };

    const handleMouseLeave = () => {
      x.set(0);
      y.set(0);
    };

    if (isHovered) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseleave', handleMouseLeave);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [isHovered, x, y, strength, disabled]);

  if (disabled) {
    return <div className={className}>{children}</div>;
  }

  return (
    <motion.div
      ref={ref}
      style={{ x: xSpring, y: ySpring }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        x.set(0);
        y.set(0);
      }}
      className={cn('relative', className)}
    >
      {children}
    </motion.div>
  );
}

// Magnetic button with enhanced effects
interface MagneticButtonProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  strength?: number;
  asDiv?: boolean; // New prop to render as div instead of button
}

export function MagneticButton({
  children,
  className,
  onClick,
  strength = 0.3,
  asDiv = false,
}: MagneticButtonProps) {
  const ref = useRef<HTMLElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const textX = useMotionValue(0);
  const textY = useMotionValue(0);
  
  const springConfig = { damping: 20, stiffness: 300 };
  const xSpring = useSpring(x, springConfig);
  const ySpring = useSpring(y, springConfig);
  const textXSpring = useSpring(textX, springConfig);
  const textYSpring = useSpring(textY, springConfig);

  const scale = useSpring(useMotionValue(1), springConfig);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!ref.current || !isHovered) return;
      
      const rect = ref.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      
      const distanceX = e.clientX - centerX;
      const distanceY = e.clientY - centerY;
      
      x.set(distanceX * strength);
      y.set(distanceY * strength);
      textX.set(distanceX * strength * 1.5);
      textY.set(distanceY * strength * 1.5);
    };

    if (isHovered) {
      window.addEventListener('mousemove', handleMouseMove);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [isHovered, x, y, textX, textY, strength]);

  const commonProps = {
    ref,
    style: { x: xSpring, y: ySpring, scale },
    onMouseEnter: () => {
      setIsHovered(true);
      scale.set(1.05);
    },
    onMouseLeave: () => {
      setIsHovered(false);
      x.set(0);
      y.set(0);
      textX.set(0);
      textY.set(0);
      scale.set(1);
    },
    onMouseDown: () => scale.set(0.95),
    onMouseUp: () => scale.set(1.05),
    className: cn(
      'relative overflow-hidden inline-block',
      className
    ),
  };

  if (asDiv) {
    return (
      <motion.div {...commonProps}>
        <motion.div
          style={{ x: textXSpring, y: textYSpring }}
          className="relative z-10 block"
        >
          {children}
        </motion.div>
      </motion.div>
    );
  }

  return (
    <motion.button
      {...commonProps}
      onClick={onClick}
    >
      <motion.span
        style={{ x: textXSpring, y: textYSpring }}
        className="relative z-10 block"
      >
        {children}
      </motion.span>
    </motion.button>
  );
}

// Magnetic navigation items
interface MagneticNavItemProps {
  children: ReactNode;
  href?: string;
  className?: string;
  strength?: number;
}

export function MagneticNavItem({
  children,
  href,
  className,
  strength = 0.2,
}: MagneticNavItemProps) {
  const ref = useRef<HTMLAnchorElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  
  const springConfig = { damping: 25, stiffness: 400 };
  const xSpring = useSpring(x, springConfig);
  const ySpring = useSpring(y, springConfig);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!ref.current || !isHovered) return;
      
      const rect = ref.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      
      const distanceX = (e.clientX - centerX) * strength;
      const distanceY = (e.clientY - centerY) * strength;
      
      x.set(distanceX);
      y.set(distanceY);
    };

    if (isHovered) {
      window.addEventListener('mousemove', handleMouseMove);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [isHovered, x, y, strength]);

  return (
    <motion.a
      ref={ref}
      href={href}
      style={{ x: xSpring, y: ySpring }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        x.set(0);
        y.set(0);
      }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className={cn('inline-block', className)}
    >
      {children}
    </motion.a>
  );
}

// Magnetic card effect
interface MagneticCardProps {
  children: ReactNode;
  className?: string;
  strength?: number;
}

export function MagneticCard({
  children,
  className,
  strength = 0.1,
}: MagneticCardProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  
  const rotateX = useMotionValue(0);
  const rotateY = useMotionValue(0);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  
  const springConfig = { damping: 20, stiffness: 200 };
  const rotateXSpring = useSpring(rotateX, springConfig);
  const rotateYSpring = useSpring(rotateY, springConfig);
  const xSpring = useSpring(x, springConfig);
  const ySpring = useSpring(y, springConfig);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!ref.current || !isHovered) return;
      
      const rect = ref.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      
      const distanceX = e.clientX - centerX;
      const distanceY = e.clientY - centerY;
      
      const percentX = distanceX / (rect.width / 2);
      const percentY = distanceY / (rect.height / 2);
      
      rotateX.set(percentY * -10);
      rotateY.set(percentX * 10);
      x.set(distanceX * strength);
      y.set(distanceY * strength);
    };

    if (isHovered) {
      window.addEventListener('mousemove', handleMouseMove);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [isHovered, rotateX, rotateY, x, y, strength]);

  return (
    <motion.div
      ref={ref}
      style={{
        x: xSpring,
        y: ySpring,
        rotateX: rotateXSpring,
        rotateY: rotateYSpring,
        transformStyle: 'preserve-3d',
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        rotateX.set(0);
        rotateY.set(0);
        x.set(0);
        y.set(0);
      }}
      className={cn('relative', className)}
    >
      {children}
    </motion.div>
  );
}