'use client';

import { useRef, ReactNode, CSSProperties } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { cn } from '@/lib/utils';

interface ScrollBlurProps {
  children: ReactNode;
  className?: string;
  maxBlur?: number;
  fadeOut?: boolean;
}

export function ScrollBlur({
  children,
  className,
  maxBlur = 10,
  fadeOut = true,
}: ScrollBlurProps) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start start', 'end start'],
  });

  const blur = useTransform(scrollYProgress, [0, 0.5], [0, maxBlur]);
  const opacity = fadeOut 
    ? useTransform(scrollYProgress, [0, 0.5], [1, 0.3])
    : 1;

  return (
    <motion.div
      ref={ref}
      style={{
        filter: useTransform(blur, (value) => `blur(${value}px)`),
        opacity,
      }}
      className={cn('relative', className)}
    >
      {children}
    </motion.div>
  );
}

// Header that blurs on scroll
interface BlurHeaderProps {
  children: ReactNode;
  className?: string;
  threshold?: number;
}

export function BlurHeader({
  children,
  className,
  threshold = 50,
}: BlurHeaderProps) {
  const { scrollY } = useScroll();
  const blur = useTransform(scrollY, [0, threshold], [0, 8]);
  const backgroundColor = useTransform(
    scrollY,
    [0, threshold],
    ['rgba(0, 0, 0, 0)', 'rgba(0, 0, 0, 0.8)']
  );

  return (
    <motion.header
      style={{
        backdropFilter: useTransform(blur, (value) => `blur(${value}px)`),
        WebkitBackdropFilter: useTransform(blur, (value) => `blur(${value}px)`),
        backgroundColor,
      }}
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-colors',
        className
      )}
    >
      {children}
    </motion.header>
  );
}

// Section with depth blur
interface DepthBlurSectionProps {
  children: ReactNode;
  className?: string;
  layers?: number;
}

export function DepthBlurSection({
  children,
  className,
  layers = 3,
}: DepthBlurSectionProps) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  });

  return (
    <div ref={ref} className={cn('relative', className)}>
      {[...Array(layers)].map((_, index) => {
        const layerProgress = index / layers;
        const blur = useTransform(
          scrollYProgress,
          [0, 0.5, 1],
          [layerProgress * 5, 0, layerProgress * 5]
        );
        const scale = useTransform(
          scrollYProgress,
          [0, 0.5, 1],
          [1 + layerProgress * 0.1, 1, 1 + layerProgress * 0.1]
        );
        const opacity = 1 - (layerProgress * 0.3);

        if (index === 0) {
          return (
            <motion.div
              key={index}
              style={{
                filter: useTransform(blur, (value) => `blur(${value}px)`),
                transform: useTransform(scale, (value) => `scale(${value})`),
                opacity,
              }}
              className="relative z-10"
            >
              {children}
            </motion.div>
          );
        }

        return (
          <motion.div
            key={index}
            style={{
              filter: useTransform(blur, (value) => `blur(${value}px)`),
              transform: useTransform(scale, (value) => `scale(${value})`),
              opacity: opacity * 0.3,
            }}
            className="absolute inset-0"
          >
            {children}
          </motion.div>
        );
      })}
    </div>
  );
}

// Glassmorphism card with scroll-based blur
interface GlassCardScrollProps {
  children: ReactNode;
  className?: string;
}

export function GlassCardScroll({
  children,
  className,
}: GlassCardScrollProps) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'center center'],
  });

  const blur = useTransform(scrollYProgress, [0, 0.5, 1], [20, 12, 20]);
  const opacity = useTransform(scrollYProgress, [0, 0.5, 1], [0.02, 0.05, 0.02]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.95, 1, 0.95]);

  return (
    <motion.div
      ref={ref}
      style={{
        scale,
        backdropFilter: useTransform(blur, (value) => `blur(${value}px)`),
        WebkitBackdropFilter: useTransform(blur, (value) => `blur(${value}px)`),
        backgroundColor: useTransform(
          opacity,
          (value) => `rgba(255, 255, 255, ${value})`
        ),
      }}
      className={cn(
        'relative rounded-2xl border border-white/10 p-8',
        'shadow-2xl',
        className
      )}
    >
      {children}
    </motion.div>
  );
}

// Progressive blur overlay
export function ProgressiveBlur({ className }: { className?: string }) {
  const { scrollY } = useScroll();
  const blur = useTransform(scrollY, [0, 500], [0, 5]);

  return (
    <motion.div
      style={{
        backdropFilter: useTransform(blur, (value) => `blur(${value}px)`),
        WebkitBackdropFilter: useTransform(blur, (value) => `blur(${value}px)`),
      }}
      className={cn(
        'fixed inset-0 pointer-events-none z-40',
        className
      )}
    />
  );
}