'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/Button';
import { Menu, X, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { MagneticNavItem, MagneticButton } from '@/components/ui/MagneticEffect';

const navItems = [
  { label: 'Home', href: '/#home', isSection: true },
  { label: 'Services', href: '/#services', isSection: true },
  { label: 'Work', href: '/work', isSection: false },
  { label: 'About', href: '/about', isSection: false },
  { label: 'Contact', href: '/#contact', isSection: true },
];

export function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const pathname = usePathname();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
      
      // Update active section based on scroll position
      const sections = ['home', 'services', 'contact'];
      const scrollPosition = window.scrollY + 100;
      
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Call once to set initial state
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, item: typeof navItems[0]) => {
    if (item.isSection && pathname === '/') {
      e.preventDefault();
      const sectionId = item.href.replace('/#', '');
      const element = document.getElementById(sectionId);
      if (element) {
        const offset = 80; // Height of fixed navigation
        const elementPosition = element.offsetTop - offset;
        window.scrollTo({
          top: elementPosition,
          behavior: 'smooth'
        });
      }
      setIsMobileMenuOpen(false);
    } else if (item.isSection && pathname !== '/') {
      // If on a different page, navigate to home first then scroll
      // This will be handled by Next.js router
      setIsMobileMenuOpen(false);
    }
  };

  const isActive = (item: typeof navItems[0]) => {
    if (item.isSection && pathname === '/') {
      const sectionId = item.href.replace('/#', '');
      return activeSection === sectionId;
    }
    return pathname === item.href;
  };

  return (
    <>
      <motion.nav
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        className={cn(
          'fixed top-0 left-0 right-0 z-50 transition-all duration-500',
          isScrolled
            ? 'glass border-b border-white/5'
            : 'bg-transparent'
        )}
      >
        <div className="container mx-auto px-4 md:px-8 lg:px-[var(--container-padding-desktop)]" style={{ maxWidth: 'var(--container-max-width)' }}>
          <div className="flex items-center justify-between h-[80px]">
            {/* Logo */}
            <Link href="/" className="group">
              <div className="flex items-center gap-[var(--spacing-sm)] transition-transform duration-200 hover:scale-105">
                <div className="w-[40px] h-[40px] rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 p-0.5">
                  <div className="w-full h-full rounded-[10px] bg-black flex items-center justify-center">
                    <span className="text-white font-black text-lg">J</span>
                  </div>
                </div>
                <span className="text-xl font-bold text-white tracking-tight">Jaspire</span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-[var(--spacing-xs)]">
              {navItems.map((item) => (
                <MagneticNavItem
                  key={item.label}
                  href={item.href}
                  strength={0.15}
                  className={cn(
                    "relative px-[var(--spacing-md)] py-[var(--spacing-sm)] font-medium text-sm transition-all duration-300 group",
                    isActive(item) 
                      ? "text-white" 
                      : "text-gray-400 hover:text-white"
                  )}
                >
                  <span onClick={(e) => handleNavClick(e as any, item)}>
                    {item.label}
                    <span className={cn(
                      "absolute bottom-0 left-[var(--spacing-md)] right-[var(--spacing-md)] h-px bg-gradient-to-r from-blue-500 to-cyan-500 transition-transform duration-300",
                      isActive(item) 
                        ? "scale-x-100" 
                        : "scale-x-0 group-hover:scale-x-100"
                    )} />
                  </span>
                </MagneticNavItem>
              ))}
            </div>

            {/* CTA Button */}
            <div className="hidden md:block">
              <MagneticButton strength={0.2} asDiv={true}>
                <Link href="/#contact">
                  <Button 
                    variant="gradient" 
                    size="md"
                    className="btn-premium font-semibold h-[48px] px-[var(--spacing-md)]"
                  >
                    Get Started
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </MagneticButton>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-[var(--spacing-sm)] text-white glass rounded-lg transition-transform hover:scale-105"
              aria-label="Toggle menu"
            >
              <AnimatePresence mode="wait">
                {isMobileMenuOpen ? (
                  <motion.div
                    key="close"
                    initial={{ rotate: -90, opacity: 0 }}
                    animate={{ rotate: 0, opacity: 1 }}
                    exit={{ rotate: 90, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <X className="w-5 h-5" />
                  </motion.div>
                ) : (
                  <motion.div
                    key="menu"
                    initial={{ rotate: 90, opacity: 0 }}
                    animate={{ rotate: 0, opacity: 1 }}
                    exit={{ rotate: -90, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Menu className="w-5 h-5" />
                  </motion.div>
                )}
              </AnimatePresence>
            </button>
          </div>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 md:hidden"
          >
            <div 
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setIsMobileMenuOpen(false)}
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="absolute right-0 top-0 bottom-0 w-full max-w-sm bg-black/95 backdrop-blur-2xl border-l border-white/10"
            >
              <div className="flex flex-col h-full pt-24 pb-8 px-8">
                <div className="flex-1">
                  <div className="flex flex-col gap-2">
                    {navItems.map((item, index) => (
                      <motion.div
                        key={item.label}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                      >
                        <Link
                          href={item.href}
                          onClick={(e) => handleNavClick(e, item)}
                          className={cn(
                            "block py-3 text-lg font-medium transition-colors",
                            isActive(item)
                              ? "text-white"
                              : "text-gray-300 hover:text-white"
                          )}
                        >
                          {item.label}
                          {isActive(item) && (
                            <motion.div
                              layoutId="mobile-active-indicator"
                              className="h-0.5 bg-gradient-to-r from-blue-500 to-cyan-500 mt-1"
                            />
                          )}
                        </Link>
                      </motion.div>
                    ))}
                  </div>
                </div>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="pt-8 border-t border-white/10"
                >
                  <Link href="/#contact" onClick={() => setIsMobileMenuOpen(false)}>
                    <Button 
                      variant="gradient" 
                      size="lg"
                      className="w-full btn-premium font-semibold h-12"
                    >
                      Get Started
                      <ArrowRight className="ml-2 w-4 h-4" />
                    </Button>
                  </Link>
                </motion.div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}