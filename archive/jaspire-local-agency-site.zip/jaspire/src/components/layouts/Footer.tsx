import Link from 'next/link';
import { Github, Twitter, Linkedin, Mail } from 'lucide-react';
import { NewsletterSignup } from '../ui/NewsletterSignup';

const footerLinks = {
  Services: [
    { label: 'Website Development', href: '/#services' },
    { label: 'E-commerce Solutions', href: '/#services' },
    { label: 'Web Applications', href: '/#services' },
    { label: 'Performance Optimization', href: '/#services' },
    { label: 'Growth Consulting', href: '/#services' },
  ],
  Company: [
    { label: 'About Jaspire', href: '/about' },
    { label: 'Case Studies', href: '/work' },
    { label: 'Client Results', href: '/results' },
    { label: 'Growth Blog', href: '/blog' },
  ],
  Resources: [
    { label: 'Free Audit', href: '/audit' },
    { label: 'ROI Calculator', href: '/calculator' },
    { label: 'Conversion Guide', href: '/guide' },
    { label: 'Knowledge Base', href: '/help' },
  ],
  Legal: [
    { label: 'Contact Us', href: '/#contact' },
    { label: 'Privacy Policy', href: '/privacy' },
    { label: 'Terms of Service', href: '/terms' },
    { label: 'SLA Agreement', href: '/sla' },
  ],
};

const socialLinks = [
  { icon: Github, href: 'https://github.com/jaspire', label: 'GitHub' },
  { icon: Twitter, href: 'https://twitter.com/jaspire', label: 'Twitter' },
  { icon: Linkedin, href: 'https://linkedin.com/company/jaspire', label: 'LinkedIn' },
  { icon: Mail, href: 'mailto:hello@jaspire.com', label: 'Email' },
];

export function Footer() {
  return (
    <footer className="relative bg-black border-t border-white/10">
      {/* Gradient line at top */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-blue-500 to-transparent" />
      
      <div className="container mx-auto px-4 md:px-8 lg:px-[var(--container-padding-desktop)] py-[var(--spacing-3xl)]" style={{ maxWidth: 'var(--container-max-width)' }}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-[var(--spacing-lg)] lg:gap-[var(--spacing-xl)]">
          {/* Brand Section */}
          <div className="lg:col-span-2">
            <Link href="/" className="inline-block mb-[var(--spacing-sm)]">
              <span className="text-3xl font-bold gradient-text">Jaspire</span>
            </Link>
            <p className="text-gray-400 mb-[var(--spacing-md)] max-w-sm">
              Transforming businesses through high-converting websites and data-driven growth strategies. 
              Trusted by 500+ companies worldwide.
            </p>
            
            {/* Newsletter Signup */}
            <div className="mb-[var(--spacing-md)]">
              <NewsletterSignup variant="compact" />
            </div>
            
            {/* Social Links */}
            <div className="flex gap-[var(--spacing-sm)]">
              {socialLinks.map((social) => {
                const Icon = social.icon;
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    aria-label={social.label}
                    className="p-[var(--spacing-xs)] rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 transition-all duration-300 group"
                  >
                    <Icon className="w-5 h-5 text-gray-400 group-hover:text-white transition-colors" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Links Sections */}
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h3 className="text-white font-semibold mb-[var(--spacing-sm)]">{title}</h3>
              <ul className="space-y-[var(--spacing-xs)]">
                {links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="text-gray-400 hover:text-white transition-colors duration-200 text-sm"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Section */}
        <div className="mt-[var(--spacing-2xl)] pt-[var(--spacing-lg)] border-t border-white/10">
          <div className="flex flex-col md:flex-row justify-between items-center gap-[var(--spacing-sm)]">
            <p className="text-gray-500 text-sm">
              © {new Date().getFullYear()} Jaspire. All rights reserved.
            </p>
            <div className="flex gap-[var(--spacing-md)]">
              <Link href="/privacy" className="text-gray-500 hover:text-white text-sm transition-colors">
                Privacy
              </Link>
              <Link href="/terms" className="text-gray-500 hover:text-white text-sm transition-colors">
                Terms
              </Link>
              <Link href="/cookies" className="text-gray-500 hover:text-white text-sm transition-colors">
                Cookies
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}