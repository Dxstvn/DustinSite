import dynamic from 'next/dynamic';
import { LoadingSpinner } from '../ui/LoadingSpinner';
import { ContentShimmer } from '../ui/ContentShimmer';

// Heavy components that should be dynamically loaded
export const DynamicThreeScene = dynamic(
  () => import('../three/HeroSceneWrapper').then(mod => ({ default: mod.HeroSceneWrapper })),
  {
    ssr: false,
    loading: () => (
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-black to-cyan-900/20">
        <div className="absolute inset-0 flex items-center justify-center">
          <LoadingSpinner />
        </div>
      </div>
    )
  }
);

export const DynamicParticleField = dynamic(
  () => import('../ui/ParticleField').then(mod => ({ default: mod.ParticleField })),
  {
    ssr: false,
    loading: () => <ContentShimmer className="w-full h-32" />
  }
);

export const DynamicTestimonialCarousel = dynamic(
  () => import('../ui/TestimonialCarousel').then(mod => ({ default: mod.TestimonialCarousel })),
  {
    ssr: false,
    loading: () => <ContentShimmer className="w-full h-64" />
  }
);

export const DynamicClientLogos = dynamic(
  () => import('../ui/ClientLogos').then(mod => ({ default: mod.ClientLogos })),
  {
    ssr: false,
    loading: () => <ContentShimmer className="w-full h-32" />
  }
);

export const DynamicContactForm = dynamic(
  () => import('../ui/ContactForm').then(mod => ({ default: mod.ContactForm })),
  {
    ssr: false,
    loading: () => <ContentShimmer className="w-full h-96" />
  }
);

export const DynamicMetricsCounter = dynamic(
  () => import('../ui/MetricsCounter').then(mod => ({ default: mod.MetricsCounter })),
  {
    ssr: false,
    loading: () => <ContentShimmer className="w-full h-24" />
  }
);

// Animation-heavy components
export const DynamicAnimatedText = dynamic(
  () => import('../ui/AnimatedText').then(mod => ({ default: mod.AnimatedText })),
  {
    ssr: false,
    loading: () => <div className="animate-pulse bg-gray-700 h-8 w-full rounded" />
  }
);

export const DynamicParallaxSection = dynamic(
  () => import('../ui/ParallaxSection').then(mod => ({ default: mod.ParallaxSection })),
  {
    ssr: false,
    loading: () => <ContentShimmer className="w-full h-full" />
  }
);

export const DynamicParallaxText = dynamic(
  () => import('../ui/ParallaxSection').then(mod => ({ default: mod.ParallaxText })),
  {
    ssr: false,
    loading: () => <ContentShimmer className="w-full h-8" />
  }
);

export const DynamicMagneticEffect = dynamic(
  () => import('../ui/MagneticEffect').then(mod => ({ default: mod.MagneticButton })),
  {
    ssr: false,
    loading: () => <div className="animate-pulse bg-gray-700 rounded w-full h-12" />
  }
);

export const DynamicMagneticCard = dynamic(
  () => import('../ui/MagneticEffect').then(mod => ({ default: mod.MagneticCard })),
  {
    ssr: false,
    loading: () => <div className="animate-pulse bg-gray-700 rounded w-full h-full" />
  }
);

export const DynamicTrustBadges = dynamic(
  () => import('../ui/TrustBadges').then(mod => ({ default: mod.TrustBadges })),
  {
    ssr: false,
    loading: () => <ContentShimmer className="w-full h-16" />
  }
);

// Chart and visualization components (if added later)
// export const DynamicChart = dynamic(
//   () => import('@/components/ui/Chart').then(mod => ({ default: mod.Chart })).catch(() => ({ default: () => null })),
//   {
//     ssr: false,
//     loading: () => <ContentShimmer className="w-full h-64" />
//   }
// );