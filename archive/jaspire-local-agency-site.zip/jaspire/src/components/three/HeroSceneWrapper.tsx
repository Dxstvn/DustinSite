'use client';

import dynamic from 'next/dynamic';
import { Suspense } from 'react';
import { ErrorBoundary } from '../ui/ErrorBoundary';
import { LoadingSpinner } from '../ui/LoadingSpinner';
import { BackgroundGrid } from '../ui/BackgroundGrid';

const OptimizedHeroScene = dynamic(
  () => import('./OptimizedHeroScene').then((mod) => ({ default: mod.OptimizedHeroScene })),
  {
    ssr: false,
    loading: () => (
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-black to-cyan-900/20">
        <BackgroundGrid />
        <div className="absolute inset-0 flex items-center justify-center">
          <LoadingSpinner />
        </div>
      </div>
    ),
  }
);

interface HeroSceneWrapperProps {
  className?: string;
}

// Fallback component for when Three.js fails
function HeroSceneFallback({ className }: { className?: string }) {
  return (
    <div className={`${className} bg-gradient-to-br from-blue-900/20 via-black to-cyan-900/20`}>
      <BackgroundGrid />
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-500 text-sm mb-2">3D Scene unavailable</p>
          <p className="text-gray-600 text-xs">Continuing with static background</p>
        </div>
      </div>
    </div>
  );
}

export function HeroSceneWrapper({ className }: HeroSceneWrapperProps) {
  return (
    <ErrorBoundary fallback={<HeroSceneFallback className={className} />}>
      <Suspense fallback={
        <div className={`${className} bg-gradient-to-br from-blue-900/20 via-black to-cyan-900/20`}>
          <BackgroundGrid />
        </div>
      }>
        <OptimizedHeroScene className={className} />
      </Suspense>
    </ErrorBoundary>
  );
}