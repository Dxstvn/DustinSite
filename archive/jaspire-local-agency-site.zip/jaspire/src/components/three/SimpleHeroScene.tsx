'use client';

import { useEffect, useRef, useMemo, useState } from 'react';
import * as THREE from 'three';
import { useInView } from 'framer-motion';

interface SimpleHeroSceneProps {
  className?: string;
  quality?: 'low' | 'medium' | 'high';
  enableAnimation?: boolean;
}

// Performance monitoring
class PerformanceMonitor {
  private frameCount = 0;
  private lastTime = 0;
  private fps = 60;
  
  update() {
    this.frameCount++;
    const now = performance.now();
    
    if (now >= this.lastTime + 1000) {
      this.fps = Math.round((this.frameCount * 1000) / (now - this.lastTime));
      this.frameCount = 0;
      this.lastTime = now;
    }
    
    return this.fps;
  }
  
  shouldReduceQuality() {
    return this.fps < 30;
  }
}

export function SimpleHeroScene({ 
  className, 
  quality = 'medium',
  enableAnimation = true 
}: SimpleHeroSceneProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const frameRef = useRef<number>(0);
  const performanceMonitor = useRef(new PerformanceMonitor());
  const [currentQuality, setCurrentQuality] = useState(quality);
  const isInView = useInView(containerRef, { margin: "-10%" });
  
  // Quality settings
  const qualitySettings = useMemo(() => ({
    low: {
      particleCount: 500,
      pixelRatio: 1,
      antialias: false,
      shadows: false,
      animationSpeed: 0.5
    },
    medium: {
      particleCount: 1500,
      pixelRatio: Math.min(window.devicePixelRatio || 1, 2),
      antialias: true,
      shadows: false,
      animationSpeed: 1
    },
    high: {
      particleCount: 3000,
      pixelRatio: Math.min(window.devicePixelRatio || 1, 2),
      antialias: true,
      shadows: true,
      animationSpeed: 1.5
    }
  }), []);
  
  const settings = qualitySettings[currentQuality];

  useEffect(() => {
    if (typeof window === 'undefined' || !containerRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.z = 5;

    // Renderer setup with quality settings
    const renderer = new THREE.WebGLRenderer({ 
      alpha: true, 
      antialias: settings.antialias,
      powerPreference: 'high-performance',
      stencil: false,
      depth: true
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(settings.pixelRatio);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    
    if (settings.shadows) {
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    }
    rendererRef.current = renderer;
    containerRef.current.appendChild(renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);

    const pointLight = new THREE.PointLight(0x0066ff, 1);
    pointLight.position.set(5, 5, 5);
    scene.add(pointLight);

    // Create optimized particles
    const particlesGeometry = new THREE.BufferGeometry();
    const particleCount = settings.particleCount;
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    const sizes = new Float32Array(particleCount);
    const colors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      const i3 = i * 3;
      
      // Spherical distribution
      const radius = Math.random() * 5 + 1;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);

      positions[i3] = radius * Math.sin(phi) * Math.cos(theta);
      positions[i3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      positions[i3 + 2] = radius * Math.cos(phi);

      // Blue gradient colors
      const intensity = 1 - (radius - 1) / 5;
      colors[i3] = 0.0;
      colors[i3 + 1] = 0.4 * intensity;
      colors[i3 + 2] = 1.0 * intensity;
    }

    particlesGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particlesGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const particlesMaterial = new THREE.PointsMaterial({
      size: 0.02,
      sizeAttenuation: true,
      vertexColors: true,
      transparent: true,
      opacity: 0.8,
      blending: THREE.AdditiveBlending,
    });

    const particles = new THREE.Points(particlesGeometry, particlesMaterial);
    scene.add(particles);

    // Create main geometry - icosahedron
    const geometry = new THREE.IcosahedronGeometry(1, 4);
    const material = new THREE.MeshPhongMaterial({
      color: 0x0066ff,
      emissive: 0x0033aa,
      emissiveIntensity: 0.2,
      shininess: 100,
      specular: 0x00ffff,
      transparent: true,
      opacity: 0.9,
    });
    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    // Handle resize
    const handleResize = () => {
      if (!rendererRef.current) return;
      
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      rendererRef.current.setSize(window.innerWidth, window.innerHeight);
    };

    // Mouse tracking
    const mouse = { x: 0, y: 0 };
    const handleMouseMove = (event: MouseEvent) => {
      mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
      mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
    };

    // Animation loop
    const animate = () => {
      frameRef.current = requestAnimationFrame(animate);

      const time = Date.now() * 0.001;

      // Rotate particles
      particles.rotation.y = time * 0.05;
      particles.rotation.x = Math.sin(time * 0.1) * 0.1;

      // Animate main mesh
      mesh.rotation.x = Math.sin(time * 0.3) * 0.1;
      mesh.rotation.y = time * 0.2;
      
      const scale = 1 + Math.sin(time * 2) * 0.05;
      mesh.scale.set(scale, scale, scale);

      // Mouse interaction
      camera.position.x = mouse.x * 0.5;
      camera.position.y = mouse.y * 0.5;
      camera.lookAt(scene.position);

      renderer.render(scene, camera);
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('mousemove', handleMouseMove);
    animate();

    // Cleanup
    return () => {
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      
      if (rendererRef.current && containerRef.current) {
        containerRef.current.removeChild(rendererRef.current.domElement);
        rendererRef.current.dispose();
      }
      
      geometry.dispose();
      material.dispose();
      particlesGeometry.dispose();
      particlesMaterial.dispose();
    };
  }, []);

  return (
    <div 
      ref={containerRef} 
      className={className}
      style={{ pointerEvents: 'none' }}
    />
  );
}