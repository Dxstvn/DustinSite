'use client';

import { useEffect, useRef, useCallback, useMemo, useState } from 'react';
import * as THREE from 'three';
import { useInView } from 'framer-motion';

interface OptimizedHeroSceneProps {
  className?: string;
  quality?: 'low' | 'medium' | 'high';
  enableAnimation?: boolean;
}

// Performance monitoring
class PerformanceMonitor {
  private frameCount = 0;
  private lastTime = 0;
  private fps = 60;
  private samples: number[] = [];
  
  update() {
    this.frameCount++;
    const now = performance.now();
    
    if (now >= this.lastTime + 1000) {
      this.fps = Math.round((this.frameCount * 1000) / (now - this.lastTime));
      this.samples.push(this.fps);
      if (this.samples.length > 5) this.samples.shift();
      
      this.frameCount = 0;
      this.lastTime = now;
    }
    
    return this.fps;
  }
  
  getAverageFPS() {
    return this.samples.length > 0 
      ? this.samples.reduce((a, b) => a + b, 0) / this.samples.length 
      : 60;
  }
  
  shouldReduceQuality() {
    return this.getAverageFPS() < 30;
  }
  
  shouldIncreaseQuality() {
    return this.getAverageFPS() > 55 && this.samples.length >= 5;
  }
}

export function OptimizedHeroScene({ 
  className, 
  quality = 'medium',
  enableAnimation = true 
}: OptimizedHeroSceneProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const frameRef = useRef<number>(0);
  const performanceMonitor = useRef(new PerformanceMonitor());
  const [currentQuality, setCurrentQuality] = useState(quality);
  const isInView = useInView(containerRef, { margin: "-10%" });
  const lastQualityCheck = useRef(0);
  
  // Detect device capabilities
  const deviceCapabilities = useMemo(() => {
    if (typeof window === 'undefined') return 'medium';
    
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    
    if (!gl) return 'low';
    
    const isMobile = window.innerWidth < 768;
    const hasHighDPI = window.devicePixelRatio > 1.5;
    const memoryInfo = (performance as any).memory;
    const hasLowMemory = memoryInfo && memoryInfo.usedJSHeapSize > 50000000;
    
    if (isMobile || hasLowMemory) return 'low';
    if (hasHighDPI) return 'high';
    return 'medium';
  }, []);
  
  // Quality settings based on device capabilities
  const qualitySettings = useMemo(() => ({
    low: {
      particleCount: Math.max(300, Math.floor(window.innerWidth / 5)),
      geometryDetail: 1,
      pixelRatio: 1,
      antialias: false,
      shadows: false,
      animationSpeed: 0.3,
      renderDistance: 50
    },
    medium: {
      particleCount: Math.max(800, Math.floor(window.innerWidth / 2)),
      geometryDetail: 2,
      pixelRatio: Math.min(window.devicePixelRatio || 1, 2),
      antialias: window.innerWidth > 1024,
      shadows: false,
      animationSpeed: 0.5,
      renderDistance: 100
    },
    high: {
      particleCount: Math.max(1500, Math.floor(window.innerWidth / 1.5)),
      geometryDetail: 3,
      pixelRatio: Math.min(window.devicePixelRatio || 1, 2),
      antialias: true,
      shadows: true,
      animationSpeed: 1,
      renderDistance: 200
    }
  }), []);
  
  const settings = qualitySettings[currentQuality];

  // Adaptive quality adjustment
  const adjustQuality = useCallback(() => {
    const now = Date.now();
    if (now - lastQualityCheck.current < 5000) return; // Check every 5 seconds
    
    lastQualityCheck.current = now;
    const monitor = performanceMonitor.current;
    
    if (monitor.shouldReduceQuality() && currentQuality !== 'low') {
      const newQuality = currentQuality === 'high' ? 'medium' : 'low';
      setCurrentQuality(newQuality);
      console.log('Reducing quality to:', newQuality, 'FPS:', monitor.getAverageFPS());
    } else if (monitor.shouldIncreaseQuality() && currentQuality !== 'high') {
      const newQuality = currentQuality === 'low' ? 'medium' : 'high';
      setCurrentQuality(newQuality);
      console.log('Increasing quality to:', newQuality, 'FPS:', monitor.getAverageFPS());
    }
  }, [currentQuality]);

  useEffect(() => {
    // Start with device-appropriate quality
    setCurrentQuality(deviceCapabilities as any);
  }, [deviceCapabilities]);

  useEffect(() => {
    if (typeof window === 'undefined' || !containerRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0x000000, 10, settings.renderDistance);
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      settings.renderDistance
    );
    camera.position.z = 5;

    // Renderer setup with optimizations
    const renderer = new THREE.WebGLRenderer({ 
      alpha: true, 
      antialias: settings.antialias,
      powerPreference: 'high-performance',
      stencil: false,
      depth: true,
      premultipliedAlpha: false,
      preserveDrawingBuffer: false
    });
    
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(settings.pixelRatio);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.sortObjects = false; // Disable sorting for performance
    
    // Optimize renderer settings
    renderer.info.autoReset = false;
    
    if (settings.shadows) {
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      renderer.shadowMap.autoUpdate = false;
    }
    
    rendererRef.current = renderer;
    containerRef.current.appendChild(renderer.domElement);

    // Optimized lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.4);
    scene.add(ambientLight);

    const pointLight = new THREE.PointLight(0x0066ff, 1, settings.renderDistance * 0.5);
    pointLight.position.set(5, 5, 5);
    
    if (settings.shadows) {
      pointLight.castShadow = true;
      pointLight.shadow.mapSize.width = 1024;
      pointLight.shadow.mapSize.height = 1024;
      pointLight.shadow.camera.near = 0.1;
      pointLight.shadow.camera.far = settings.renderDistance;
    }
    
    scene.add(pointLight);

    // Create optimized particle system
    const particlesGeometry = new THREE.BufferGeometry();
    const particleCount = settings.particleCount;
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    const velocities = new Float32Array(particleCount * 3);
    const sizes = new Float32Array(particleCount);

    // Generate particles with optimized distribution
    for (let i = 0; i < particleCount; i++) {
      const i3 = i * 3;
      
      // More efficient spherical distribution
      const u = Math.random();
      const v = Math.random();
      const theta = u * 2.0 * Math.PI;
      const phi = Math.acos(2.0 * v - 1.0);
      const r = Math.cbrt(Math.random()) * 4 + 1;

      positions[i3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      positions[i3 + 2] = r * Math.cos(phi);

      // Subtle velocities for drift
      velocities[i3] = (Math.random() - 0.5) * 0.01;
      velocities[i3 + 1] = (Math.random() - 0.5) * 0.01;
      velocities[i3 + 2] = (Math.random() - 0.5) * 0.01;

      // Color gradient based on distance
      const intensity = Math.max(0.2, 1 - (r - 1) / 4);
      colors[i3] = 0.1 * intensity;
      colors[i3 + 1] = 0.4 * intensity;
      colors[i3 + 2] = 1.0 * intensity;
      
      sizes[i] = Math.random() * 2 + 0.5;
    }

    particlesGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particlesGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    particlesGeometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1));

    // Optimized particle material
    const particlesMaterial = new THREE.PointsMaterial({
      size: 0.03,
      sizeAttenuation: true,
      vertexColors: true,
      transparent: true,
      opacity: 0.6,
      blending: THREE.AdditiveBlending,
      depthWrite: false, // Optimization for transparent objects
    });

    const particles = new THREE.Points(particlesGeometry, particlesMaterial);
    scene.add(particles);

    // Create LOD geometry system
    const createLODGeometry = () => {
      const lod = new THREE.LOD();
      
      // High detail (close)
      const highGeometry = new THREE.IcosahedronGeometry(1, settings.geometryDetail);
      const highMaterial = new THREE.MeshPhongMaterial({
        color: 0x0066ff,
        emissive: 0x001144,
        emissiveIntensity: 0.1,
        shininess: 50,
        transparent: true,
        opacity: 0.8,
      });
      const highMesh = new THREE.Mesh(highGeometry, highMaterial);
      lod.addLevel(highMesh, 0);

      // Medium detail
      const medGeometry = new THREE.IcosahedronGeometry(1, Math.max(1, settings.geometryDetail - 1));
      const medMaterial = highMaterial.clone();
      const medMesh = new THREE.Mesh(medGeometry, medMaterial);
      lod.addLevel(medMesh, 10);

      // Low detail (far)
      const lowGeometry = new THREE.IcosahedronGeometry(1, 0);
      const lowMaterial = highMaterial.clone();
      const lowMesh = new THREE.Mesh(lowGeometry, lowMaterial);
      lod.addLevel(lowMesh, 20);

      return lod;
    };

    const mainGeometry = createLODGeometry();
    scene.add(mainGeometry);

    // Optimized animation loop
    let lastTime = 0;
    const targetFPS = 60;
    const frameInterval = 1000 / targetFPS;

    const animate = (currentTime: number) => {
      if (!isInView && !enableAnimation) {
        frameRef.current = requestAnimationFrame(animate);
        return;
      }

      const deltaTime = currentTime - lastTime;
      
      if (deltaTime >= frameInterval) {
        // Performance monitoring
        const fps = performanceMonitor.current.update();
        adjustQuality();

        if (enableAnimation && isInView) {
          const time = currentTime * 0.001 * settings.animationSpeed;
          
          // Rotate main geometry
          mainGeometry.rotation.x = Math.sin(time * 0.2) * 0.1;
          mainGeometry.rotation.y = time * 0.1;
          mainGeometry.rotation.z = Math.cos(time * 0.1) * 0.05;

          // Animate particles with drift
          const positions = particles.geometry.attributes.position.array as Float32Array;
          for (let i = 0; i < particleCount; i++) {
            const i3 = i * 3;
            positions[i3] += velocities[i3];
            positions[i3 + 1] += velocities[i3 + 1];
            positions[i3 + 2] += velocities[i3 + 2];
          }
          particles.geometry.attributes.position.needsUpdate = true;
        }

        renderer.render(scene, camera);
        renderer.info.reset();
        lastTime = currentTime;
      }

      frameRef.current = requestAnimationFrame(animate);
    };

    // Handle resize with debouncing
    let resizeTimeout: NodeJS.Timeout;
    const handleResize = () => {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(() => {
        const width = window.innerWidth;
        const height = window.innerHeight;
        
        camera.aspect = width / height;
        camera.updateProjectionMatrix();
        renderer.setSize(width, height);
      }, 100);
    };

    window.addEventListener('resize', handleResize);
    
    // Start animation
    frameRef.current = requestAnimationFrame(animate);

    // Cleanup
    return () => {
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
      
      window.removeEventListener('resize', handleResize);
      clearTimeout(resizeTimeout);
      
      if (containerRef.current && renderer.domElement) {
        containerRef.current.removeChild(renderer.domElement);
      }
      
      // Dispose of resources
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh) {
          object.geometry.dispose();
          if (Array.isArray(object.material)) {
            object.material.forEach(material => material.dispose());
          } else {
            object.material.dispose();
          }
        }
      });
      
      renderer.dispose();
    };
  }, [settings, isInView, enableAnimation, adjustQuality]);

  return (
    <div 
      ref={containerRef} 
      className={className}
      style={{ 
        willChange: 'transform',
        transform: 'translateZ(0)' // Force GPU acceleration
      }}
    />
  );
}