'use client';

import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface ParticleFieldProps {
  count?: number;
}

export function ParticleField({ count = 5000 }: ParticleFieldProps) {
  const points = useRef<THREE.Points>(null!);
  const mousePosition = useRef({ x: 0, y: 0 });

  // Generate particle positions and colors
  const [positions, colors] = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
      const i3 = i * 3;

      // Create a spherical distribution
      const radius = Math.random() * 5 + 1;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);

      positions[i3] = radius * Math.sin(phi) * Math.cos(theta);
      positions[i3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      positions[i3 + 2] = radius * Math.cos(phi);

      // Color gradient based on distance
      const intensity = 1 - (radius - 1) / 5;
      colors[i3] = 0.0; // R
      colors[i3 + 1] = 0.4 * intensity; // G (cyan tint)
      colors[i3 + 2] = 1.0 * intensity; // B (blue)
    }

    return [positions, colors];
  }, [count]);

  // Store original positions for animation
  const originalPositions = useMemo(() => [...positions], [positions]);

  // Animation loop
  useFrame((state) => {
    if (!points.current) return;

    const time = state.clock.getElapsedTime();
    const positions = points.current.geometry.attributes.position.array as Float32Array;

    // Gentle floating animation
    for (let i = 0; i < count; i++) {
      const i3 = i * 3;
      
      // Add wave motion
      positions[i3] = originalPositions[i3] + Math.sin(time * 0.3 + i * 0.01) * 0.05;
      positions[i3 + 1] = originalPositions[i3 + 1] + Math.cos(time * 0.2 + i * 0.01) * 0.05;
      positions[i3 + 2] = originalPositions[i3 + 2] + Math.sin(time * 0.4 + i * 0.01) * 0.05;
    }

    // Rotate the entire particle system
    points.current.rotation.y = time * 0.05;
    points.current.rotation.x = Math.sin(time * 0.1) * 0.1;

    points.current.geometry.attributes.position.needsUpdate = true;
  });

  return (
    <points ref={points}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          count={count}
          array={colors}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.02}
        sizeAttenuation={true}
        vertexColors={true}
        transparent={true}
        opacity={0.8}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
      />
    </points>
  );
}