'use client';

import { Suspense, useEffect, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { PerspectiveCamera, OrbitControls, PerformanceMonitor } from '@react-three/drei';
import { EffectComposer, Bloom, ChromaticAberration } from '@react-three/postprocessing';
import { Vector2 } from 'three';
import { ParticleField } from './ParticleField';
import { HeroObject } from './HeroObject';

interface HeroSceneProps {
  className?: string;
}

export function HeroScene({ className }: HeroSceneProps) {
  const [dpr, setDpr] = useState(1.5);
  const [particleCount, setParticleCount] = useState(5000);
  const [enableEffects, setEnableEffects] = useState(true);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    // Detect mobile devices and adjust performance
    const checkMobile = () => {
      const mobile = window.innerWidth < 768 || /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
      setIsMobile(mobile);
      
      if (mobile) {
        setDpr(1);
        setParticleCount(1000);
        setEnableEffects(false);
      } else {
        // Check GPU capabilities
        const canvas = document.createElement('canvas');
        const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
        if (gl) {
          const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
          if (debugInfo) {
            const renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
            // Reduce quality for integrated graphics
            if (renderer.toLowerCase().includes('intel')) {
              setDpr(1);
              setParticleCount(2500);
            }
          }
        }
      }
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Fallback for low-end devices
  if (isMobile && particleCount < 500) {
    return (
      <div className={`${className} bg-gradient-to-br from-blue-900/20 via-black to-cyan-900/20`}>
        <div className="absolute inset-0 bg-[url('/grid.svg')] bg-center opacity-20" />
      </div>
    );
  }

  return (
    <div className={className}>
      <Canvas
        dpr={dpr}
        gl={{
          antialias: !isMobile,
          powerPreference: 'high-performance',
          alpha: true,
        }}
        style={{ background: 'transparent' }}
      >
        <Suspense fallback={null}>
          <PerspectiveCamera makeDefault position={[0, 0, 5]} fov={75} />
          
          {/* Lighting */}
          <ambientLight intensity={0.5} />
          <pointLight position={[10, 10, 10]} intensity={1} />
          <pointLight position={[-10, -10, -10]} intensity={0.5} color="#00ffff" />
          
          {/* 3D Objects */}
          <ParticleField count={particleCount} />
          <HeroObject />
          
          {/* Camera Controls (disabled on mobile) */}
          {!isMobile && (
            <OrbitControls
              enableZoom={false}
              enablePan={false}
              enableRotate={true}
              autoRotate={true}
              autoRotateSpeed={0.5}
              minPolarAngle={Math.PI / 3}
              maxPolarAngle={Math.PI / 1.5}
            />
          )}
          
          {/* Performance monitoring and auto-adjustment */}
          <PerformanceMonitor
            onDecline={() => {
              setDpr(1);
              if (particleCount > 1000) {
                setParticleCount(Math.floor(particleCount * 0.75));
              }
              if (enableEffects) {
                setEnableEffects(false);
              }
            }}
            onIncline={() => {
              if (dpr < 1.5 && !isMobile) {
                setDpr(1.5);
              }
            }}
          />
          
          {/* Post-processing effects */}
          {enableEffects && !isMobile && (
            <EffectComposer>
              <Bloom
                intensity={0.5}
                luminanceThreshold={0.9}
                luminanceSmoothing={0.025}
                mipmapBlur
              />
              <ChromaticAberration
                offset={new Vector2(0.0005, 0.0005)}
                radialModulation={false}
                modulationOffset={0}
              />
            </EffectComposer>
          )}
        </Suspense>
      </Canvas>
    </div>
  );
}