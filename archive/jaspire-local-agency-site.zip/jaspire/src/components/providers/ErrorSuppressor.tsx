'use client';

import { useEffect } from 'react';

export function ErrorSuppressor({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    // Only in development
    if (process.env.NODE_ENV === 'development') {
      // Suppress Next.js DevTools errors
      const originalError = window.console.error;
      
      window.console.error = (...args) => {
        // Filter out Next.js DevTools errors
        const errorString = args[0]?.toString() || '';
        
        if (
          errorString.includes('next-devtools') ||
          errorString.includes('Failed to fetch') ||
          errorString.includes('DevTools') ||
          errorString.includes('__nextjs') ||
          errorString.includes('_next/static/chunks/node_modules_next_dist_compiled_next-devtools')
        ) {
          // Silently ignore these errors
          return;
        }
        
        // Log other errors normally
        originalError.apply(console, args);
      };
      
      // Also handle unhandled promise rejections from DevTools
      const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
        const reason = event.reason?.toString() || '';
        
        if (
          reason.includes('next-devtools') ||
          reason.includes('Failed to fetch') ||
          (event.reason?.stack && event.reason.stack.includes('next-devtools'))
        ) {
          event.preventDefault();
          return;
        }
      };
      
      window.addEventListener('unhandledrejection', handleUnhandledRejection);
      
      // Cleanup
      return () => {
        window.console.error = originalError;
        window.removeEventListener('unhandledrejection', handleUnhandledRejection);
      };
    }
  }, []);
  
  return <>{children}</>;
}