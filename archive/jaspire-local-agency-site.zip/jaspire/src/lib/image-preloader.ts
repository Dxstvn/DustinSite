// Image preloader for critical assets
class ImagePreloader {
  private loadedImages = new Set<string>();
  private loadingImages = new Map<string, Promise<void>>();

  /**
   * Preload a single image
   */
  preloadImage(src: string): Promise<void> {
    if (this.loadedImages.has(src)) {
      return Promise.resolve();
    }

    if (this.loadingImages.has(src)) {
      return this.loadingImages.get(src)!;
    }

    const promise = new Promise<void>((resolve, reject) => {
      const img = new Image();
      
      img.onload = () => {
        this.loadedImages.add(src);
        this.loadingImages.delete(src);
        resolve();
      };

      img.onerror = () => {
        this.loadingImages.delete(src);
        reject(new Error(`Failed to load image: ${src}`));
      };

      img.src = src;
    });

    this.loadingImages.set(src, promise);
    return promise;
  }

  /**
   * Preload multiple images in parallel
   */
  preloadImages(sources: string[]): Promise<void[]> {
    return Promise.all(sources.map(src => this.preloadImage(src)));
  }

  /**
   * Preload images with priority queue
   */
  preloadImagesWithPriority(
    prioritySources: string[], 
    normalSources: string[] = []
  ): Promise<void> {
    return this.preloadImages(prioritySources).then(() => {
      if (normalSources.length > 0) {
        // Load normal priority images after critical ones
        return this.preloadImages(normalSources).then(() => {});
      }
    });
  }

  /**
   * Check if image is already loaded
   */
  isImageLoaded(src: string): boolean {
    return this.loadedImages.has(src);
  }

  /**
   * Clear loaded images cache
   */
  clear(): void {
    this.loadedImages.clear();
    this.loadingImages.clear();
  }
}

// Singleton instance
export const imagePreloader = new ImagePreloader();

// Hook for React components
import { useEffect } from 'react';

export function useImagePreloader(
  images: string[] | { priority: string[], normal: string[] },
  preload: boolean = true
) {
  useEffect(() => {
    if (!preload || typeof window === 'undefined') return;

    if (Array.isArray(images)) {
      imagePreloader.preloadImages(images).catch(console.warn);
    } else {
      imagePreloader
        .preloadImagesWithPriority(images.priority, images.normal)
        .catch(console.warn);
    }
  }, [images, preload]);
}

// Critical images that should be preloaded immediately
export const CRITICAL_IMAGES = {
  // Hero section backgrounds
  heroBackgrounds: [
    '/grid.svg',
    '/hero-bg.jpg',
    '/hero-overlay.png'
  ],
  // Client logos (first 4 for above-the-fold)
  clientLogos: [
    '/logos/techflow.svg',
    '/logos/greenscope.svg', 
    '/logos/cloudvault.svg',
    '/logos/financeforward.svg'
  ],
  // UI assets
  uiAssets: [
    '/icons/check.svg',
    '/icons/arrow.svg',
    '/icons/play.svg'
  ]
};

// Preload critical images on app load
export function preloadCriticalImages() {
  if (typeof window === 'undefined') return;

  imagePreloader.preloadImagesWithPriority(
    [
      ...CRITICAL_IMAGES.heroBackgrounds,
      ...CRITICAL_IMAGES.clientLogos.slice(0, 4)
    ],
    [
      ...CRITICAL_IMAGES.clientLogos.slice(4),
      ...CRITICAL_IMAGES.uiAssets
    ]
  ).catch(console.warn);
}