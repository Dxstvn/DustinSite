/**
 * Safe fetch wrapper that handles errors gracefully
 */
export async function safeFetch(
  url: string,
  options?: RequestInit
): Promise<Response | null> {
  try {
    const response = await fetch(url, {
      ...options,
      // Add timeout to prevent hanging requests
      signal: AbortSignal.timeout(10000),
    });
    
    if (!response.ok) {
      console.warn(`Fetch failed: ${response.status} ${response.statusText}`);
      return null;
    }
    
    return response;
  } catch (error) {
    // Only log non-DevTools errors
    if (error instanceof Error) {
      const errorMessage = error.message.toLowerCase();
      const isDevToolsError = 
        errorMessage.includes('devtools') ||
        errorMessage.includes('next-devtools') ||
        (error.stack && error.stack.includes('next-devtools'));
      
      if (!isDevToolsError) {
        console.error('Fetch error:', error);
      }
    }
    
    return null;
  }
}

/**
 * Fetch with automatic retry logic
 */
export async function fetchWithRetry(
  url: string,
  options?: RequestInit,
  maxRetries = 3,
  delay = 1000
): Promise<Response | null> {
  for (let i = 0; i < maxRetries; i++) {
    const response = await safeFetch(url, options);
    
    if (response) {
      return response;
    }
    
    // Don't retry on last attempt
    if (i < maxRetries - 1) {
      await new Promise(resolve => setTimeout(resolve, delay * (i + 1)));
    }
  }
  
  return null;
}