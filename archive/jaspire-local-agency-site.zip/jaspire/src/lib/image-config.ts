// Image optimization configuration

export interface ImageConfig {
  quality: number;
  format?: 'webp' | 'avif' | 'auto';
  blur?: boolean;
  responsive?: boolean;
  sizes?: string;
}

// Default image configurations for different use cases
export const imageConfigs = {
  // Hero images - high quality, optimized for performance
  hero: {
    quality: 90,
    format: 'webp' as const,
    blur: true,
    responsive: true,
    sizes: '100vw'
  },

  // Client logos - crisp, small file sizes
  logos: {
    quality: 95,
    format: 'auto' as const,
    blur: false,
    responsive: true,
    sizes: '(max-width: 768px) 120px, 150px'
  },

  // Feature images - balanced quality and size
  features: {
    quality: 85,
    format: 'webp' as const,
    blur: true,
    responsive: true,
    sizes: '(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw'
  },

  // Thumbnails - smaller, optimized for grids
  thumbnails: {
    quality: 80,
    format: 'webp' as const,
    blur: true,
    responsive: true,
    sizes: '(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 25vw'
  },

  // Background images - optimized for large areas
  backgrounds: {
    quality: 75,
    format: 'webp' as const,
    blur: true,
    responsive: true,
    sizes: '100vw'
  },

  // Icons - small, crisp
  icons: {
    quality: 100,
    format: 'auto' as const,
    blur: false,
    responsive: false,
    sizes: '24px'
  }
};

// Responsive image sizes presets
export const responsiveSizes = {
  fullWidth: '100vw',
  halfWidth: '(max-width: 768px) 100vw, 50vw',
  thirdWidth: '(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw',
  quarterWidth: '(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 25vw',
  fixed: {
    small: '(max-width: 768px) 120px, 150px',
    medium: '(max-width: 768px) 200px, 300px',
    large: '(max-width: 768px) 300px, 500px'
  }
};

// Image optimization utilities
export const imageUtils = {
  /**
   * Generate optimized image source URL
   */
  getOptimizedSrc: (src: string, config: ImageConfig) => {
    if (src.startsWith('data:') || src.startsWith('blob:')) {
      return src;
    }

    // For external URLs, apply format optimization if supported
    if (src.startsWith('http')) {
      try {
        const url = new URL(src);
        if (config.format && config.format !== 'auto') {
          url.searchParams.set('format', config.format);
        }
        if (config.quality) {
          url.searchParams.set('quality', config.quality.toString());
        }
        return url.toString();
      } catch {
        return src;
      }
    }

    // For local images, Next.js will handle optimization
    return src;
  },

  /**
   * Generate blur placeholder data URL
   */
  generateBlurDataURL: (width: number, height: number, color = '#1a1a2e') => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    if (!ctx) return '';
    
    canvas.width = 10;
    canvas.height = Math.round((height / width) * 10);
    
    // Create gradient
    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, color);
    gradient.addColorStop(0.5, `${color}88`);
    gradient.addColorStop(1, `${color}44`);
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    return canvas.toDataURL('image/jpeg', 0.1);
  },

  /**
   * Detect WebP support
   */
  supportsWebP: (): boolean => {
    if (typeof window === 'undefined') return true;
    
    const canvas = document.createElement('canvas');
    canvas.width = 1;
    canvas.height = 1;
    return canvas.toDataURL('image/webp').indexOf('data:image/webp') === 0;
  },

  /**
   * Detect AVIF support
   */
  supportsAVIF: (): boolean => {
    if (typeof window === 'undefined') return false;
    
    const canvas = document.createElement('canvas');
    canvas.width = 1;
    canvas.height = 1;
    return canvas.toDataURL('image/avif').indexOf('data:image/avif') === 0;
  }
};