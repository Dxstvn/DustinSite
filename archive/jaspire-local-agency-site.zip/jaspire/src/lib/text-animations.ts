'use client';

import { Variants } from 'framer-motion';

// Text animation variants
export const textAnimations = {
  // Fade in from bottom
  fadeInUp: {
    initial: {
      opacity: 0,
      y: 20,
    },
    animate: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  },
  
  // Fade in from top
  fadeInDown: {
    initial: {
      opacity: 0,
      y: -20,
    },
    animate: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  },
  
  // Scale in with fade
  scaleIn: {
    initial: {
      opacity: 0,
      scale: 0.95,
    },
    animate: {
      opacity: 1,
      scale: 1,
      transition: {
        duration: 0.5,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  },
  
  // Blur in effect
  blurIn: {
    initial: {
      opacity: 0,
      filter: 'blur(10px)',
    },
    animate: {
      opacity: 1,
      filter: 'blur(0px)',
      transition: {
        duration: 0.8,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  },
  
  // Letter by letter animation
  letterByLetter: {
    initial: {
      opacity: 0,
    },
    animate: {
      opacity: 1,
      transition: {
        staggerChildren: 0.03,
      },
    },
    child: {
      initial: {
        opacity: 0,
        y: 10,
      },
      animate: {
        opacity: 1,
        y: 0,
        transition: {
          duration: 0.4,
        },
      },
    },
  },
  
  // Word by word animation
  wordByWord: {
    initial: {
      opacity: 0,
    },
    animate: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08,
      },
    },
    child: {
      initial: {
        opacity: 0,
        x: -10,
      },
      animate: {
        opacity: 1,
        x: 0,
        transition: {
          duration: 0.4,
        },
      },
    },
  },
  
  // Typewriter effect
  typewriter: {
    initial: {
      width: '0%',
    },
    animate: {
      width: '100%',
      transition: {
        duration: 2,
        ease: 'linear',
      },
    },
  },
  
  // Gradient animation
  gradient: {
    initial: {
      backgroundPosition: '0% 50%',
    },
    animate: {
      backgroundPosition: '100% 50%',
      transition: {
        duration: 3,
        ease: 'linear',
        repeat: Infinity,
        repeatType: 'reverse' as const,
      },
    },
  },
};

// Heading animation variants with stagger
export const headingAnimation: Variants = {
  initial: {
    opacity: 0,
  },
  animate: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
  child: {
    initial: {
      opacity: 0,
      y: 30,
    },
    animate: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  },
};

// Paragraph animation with fade and slide
export const paragraphAnimation: Variants = {
  initial: {
    opacity: 0,
    y: 20,
  },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      delay: 0.2,
      ease: [0.22, 1, 0.36, 1],
    },
  },
};

// Text reveal animation
export const textReveal: Variants = {
  initial: {
    opacity: 0,
    clipPath: 'polygon(0 0, 0 0, 0 100%, 0% 100%)',
  },
  animate: {
    opacity: 1,
    clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)',
    transition: {
      duration: 0.8,
      ease: [0.22, 1, 0.36, 1],
    },
  },
};

// Counter animation for numbers
export const counterAnimation = {
  initial: { opacity: 0, scale: 0.5 },
  animate: { 
    opacity: 1, 
    scale: 1,
    transition: {
      duration: 0.5,
      ease: [0.175, 0.885, 0.32, 1.275],
    },
  },
};

// Hover text effects
export const hoverTextEffect = {
  rest: {
    color: 'rgba(255, 255, 255, 0.7)',
    transition: {
      duration: 0.2,
      ease: 'easeInOut',
    },
  },
  hover: {
    color: 'rgba(255, 255, 255, 1)',
    textShadow: '0 0 20px rgba(0, 102, 255, 0.5)',
    transition: {
      duration: 0.2,
      ease: 'easeInOut',
    },
  },
};

// Split text utility (returns array of strings for processing)
export const splitTextToArray = (text: string, type: 'letters' | 'words' = 'letters'): string[] => {
  if (type === 'letters') {
    return text.split('').map(char => char === ' ' ? '\u00A0' : char);
  } else {
    return text.split(' ');
  }
};