import { Inter, JetBrains_Mono } from 'next/font/google';

// Inter for body text and display - variable font with all weights
export const inter = Inter({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-sans',
  weight: ['400', '500', '600', '700', '800'],
  preload: true,
  fallback: ['system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'sans-serif'],
});

// JetBrains Mono for code and monospace elements
export const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-mono',
  weight: ['400', '500', '600', '700'],
  preload: true,
  fallback: ['ui-monospace', 'SFMono-Regular', 'Consolas', 'monospace'],
});