/**
 * Unified animation configurations for consistent micro-animations
 */

// Timing functions matching our CSS design tokens
export const easings = {
  linear: [0, 0, 1, 1],
  inOut: [0.4, 0, 0.2, 1],
  out: [0, 0, 0.2, 1],
  in: [0.4, 0, 1, 1],
  outExpo: [0.19, 1, 0.22, 1],
  inOutExpo: [0.87, 0, 0.13, 1],
  spring: [0.175, 0.885, 0.32, 1.275],
  bounce: [0.68, -0.55, 0.265, 1.55],
  smooth: [0.25, 0.46, 0.45, 0.94],
} as const;

// Duration values in seconds for Framer Motion
export const durations = {
  instant: 0.1,
  fast: 0.2,
  base: 0.3,
  slow: 0.5,
  slower: 0.8,
  slowest: 1.2,
} as const;

// Stagger delays for list animations
export const staggers = {
  fast: 0.05,
  base: 0.1,
  slow: 0.15,
  slower: 0.2,
} as const;

// Framer Motion Variants
export const variants = {
  // Fade animations
  fadeIn: {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    exit: { opacity: 0 },
  },
  
  // Slide animations
  slideUp: {
    initial: { y: 20, opacity: 0 },
    animate: { y: 0, opacity: 1 },
    exit: { y: -20, opacity: 0 },
  },
  
  slideDown: {
    initial: { y: -20, opacity: 0 },
    animate: { y: 0, opacity: 1 },
    exit: { y: 20, opacity: 0 },
  },
  
  slideLeft: {
    initial: { x: 20, opacity: 0 },
    animate: { x: 0, opacity: 1 },
    exit: { x: -20, opacity: 0 },
  },
  
  slideRight: {
    initial: { x: -20, opacity: 0 },
    animate: { x: 0, opacity: 1 },
    exit: { x: 20, opacity: 0 },
  },
  
  // Scale animations
  scaleIn: {
    initial: { scale: 0.95, opacity: 0 },
    animate: { scale: 1, opacity: 1 },
    exit: { scale: 0.95, opacity: 0 },
  },
  
  // Container for stagger children
  container: {
    initial: {},
    animate: {
      transition: {
        staggerChildren: staggers.base,
      },
    },
  },
  
  // Item for stagger animation
  item: {
    initial: { y: 20, opacity: 0 },
    animate: { 
      y: 0, 
      opacity: 1,
      transition: {
        duration: durations.base,
        ease: easings.outExpo,
      },
    },
  },
};

// Hover animations for interactive elements
export const hoverVariants = {
  lift: {
    y: -2,
    transition: {
      duration: durations.fast,
      ease: easings.out,
    },
  },
  
  scale: {
    scale: 1.05,
    transition: {
      duration: durations.fast,
      ease: easings.out,
    },
  },
  
  glow: {
    boxShadow: '0 0 20px rgba(0, 102, 255, 0.3)',
    transition: {
      duration: durations.base,
      ease: easings.out,
    },
  },
};

// Tap/Press animations
export const tapVariants = {
  scale: 0.98,
  transition: {
    duration: durations.instant,
    ease: easings.out,
  },
};

// Section entrance animations
export const sectionVariants = {
  offscreen: {
    y: 50,
    opacity: 0,
  },
  onscreen: {
    y: 0,
    opacity: 1,
    transition: {
      duration: durations.slow,
      ease: easings.outExpo,
    },
  },
};

// GSAP animation configs
export const gsapConfig = {
  defaults: {
    ease: 'expo.out',
    duration: 0.8,
  },
  
  fadeIn: {
    opacity: 0,
    y: 30,
    duration: 0.8,
    ease: 'expo.out',
  },
  
  slideUp: {
    y: 50,
    opacity: 0,
    duration: 0.8,
    ease: 'expo.out',
  },
  
  stagger: {
    each: 0.1,
    from: 'start',
  },
};

// CSS transition utilities
export const transitions = {
  all: `all var(--duration-base) var(--ease-out)`,
  transform: `transform var(--duration-base) var(--ease-out-expo)`,
  opacity: `opacity var(--duration-base) var(--ease-out)`,
  colors: `color var(--duration-fast) var(--ease-out), background-color var(--duration-fast) var(--ease-out), border-color var(--duration-fast) var(--ease-out)`,
  shadow: `box-shadow var(--duration-base) var(--ease-out)`,
} as const;