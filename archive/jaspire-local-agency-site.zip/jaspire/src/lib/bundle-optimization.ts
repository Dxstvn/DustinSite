// Bundle optimization utilities

// Lazy load heavy dependencies
export const loadFramerMotion = () => import('framer-motion');
export const loadThree = () => import('three');
export const loadGSAP = () => import('gsap');

// Code splitting for feature modules
export const loadAnimations = () => import('./animations');
export const loadUtils = () => import('./utils');

// Dynamic feature loading
export class FeatureLoader {
  private static loadedFeatures = new Set<string>();
  private static loadingPromises = new Map<string, Promise<any>>();

  static async loadFeature<T>(
    featureName: string, 
    loader: () => Promise<T>
  ): Promise<T> {
    if (this.loadedFeatures.has(featureName)) {
      return loader();
    }

    if (this.loadingPromises.has(featureName)) {
      return this.loadingPromises.get(featureName)!;
    }

    const promise = loader().then(result => {
      this.loadedFeatures.add(featureName);
      this.loadingPromises.delete(featureName);
      return result;
    });

    this.loadingPromises.set(featureName, promise);
    return promise;
  }

  static isFeatureLoaded(featureName: string): boolean {
    return this.loadedFeatures.has(featureName);
  }
}

// Tree-shakeable imports
export const importMotionComponents = async () => {
  const { motion, AnimatePresence, useInView } = await import('framer-motion');
  return { motion, AnimatePresence, useInView };
};

export const importThreeEssentials = async () => {
  const THREE = await import('three');
  return {
    Scene: THREE.Scene,
    WebGLRenderer: THREE.WebGLRenderer,
    PerspectiveCamera: THREE.PerspectiveCamera,
    BufferGeometry: THREE.BufferGeometry,
    Points: THREE.Points,
    PointsMaterial: THREE.PointsMaterial,
  };
};

// Preload critical modules
export const preloadCriticalModules = () => {
  // Preload modules that are likely to be used soon
  if (typeof window !== 'undefined') {
    setTimeout(() => {
      import('framer-motion');
      import('../components/ui/AnimatedText');
    }, 2000);
  }
};

// Resource hints for better loading
export const addResourceHints = () => {
  if (typeof document === 'undefined') return;

  const head = document.head;

  // Preload critical fonts
  const fontPreloads = [
    'https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap',
    'https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@100..800&display=swap'
  ];

  fontPreloads.forEach(href => {
    if (!document.querySelector(`link[href="${href}"]`)) {
      const link = document.createElement('link');
      link.rel = 'preload';
      link.as = 'style';
      link.href = href;
      head.appendChild(link);
    }
  });

  // DNS prefetch for external resources
  const dnsPrefetches = [
    'https://fonts.googleapis.com',
    'https://fonts.gstatic.com'
  ];

  dnsPrefetches.forEach(href => {
    if (!document.querySelector(`link[href="${href}"][rel="dns-prefetch"]`)) {
      const link = document.createElement('link');
      link.rel = 'dns-prefetch';
      link.href = href;
      head.appendChild(link);
    }
  });
};

// Intersection observer for component loading
export const useIntersectionLoader = (
  ref: React.RefObject<Element>,
  loader: () => Promise<any>,
  options: IntersectionObserverInit = {}
) => {
  if (typeof window === 'undefined') return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        loader();
        observer.unobserve(entry.target);
      }
    });
  }, { rootMargin: '100px', ...options });

  if (ref.current) {
    observer.observe(ref.current);
  }

  return () => observer.disconnect();
};