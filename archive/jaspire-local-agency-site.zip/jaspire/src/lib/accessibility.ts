// Accessibility utilities and helpers

export const ACCESSIBILITY_CONFIG = {
  // ARIA roles and labels
  navigation: {
    primary: 'main navigation',
    secondary: 'secondary navigation',
    breadcrumb: 'breadcrumb navigation',
    footer: 'footer navigation'
  },
  
  // Skip links
  skipLinks: [
    { href: '#main-content', text: 'Skip to main content' },
    { href: '#navigation', text: 'Skip to navigation' },
    { href: '#footer', text: 'Skip to footer' }
  ],

  // Focus management
  focusableSelectors: [
    'a[href]',
    'button:not([disabled])',
    'input:not([disabled])',
    'select:not([disabled])',
    'textarea:not([disabled])',
    '[tabindex]:not([tabindex="-1"])',
    'details',
    'summary'
  ].join(', '),

  // Color contrast ratios (WCAG AA compliance)
  colorContrast: {
    normal: 4.5,
    large: 3,
    enhanced: 7 // AAA level
  }
};

// Focus trap utility
export class FocusTrap {
  private element: HTMLElement;
  private focusableElements: HTMLElement[] = [];
  private firstFocusable: HTMLElement | null = null;
  private lastFocusable: HTMLElement | null = null;

  constructor(element: HTMLElement) {
    this.element = element;
    this.updateFocusableElements();
  }

  private updateFocusableElements() {
    this.focusableElements = Array.from(
      this.element.querySelectorAll(ACCESSIBILITY_CONFIG.focusableSelectors)
    ) as HTMLElement[];
    
    this.firstFocusable = this.focusableElements[0] || null;
    this.lastFocusable = this.focusableElements[this.focusableElements.length - 1] || null;
  }

  activate() {
    document.addEventListener('keydown', this.handleKeydown);
    this.firstFocusable?.focus();
  }

  deactivate() {
    document.removeEventListener('keydown', this.handleKeydown);
  }

  private handleKeydown = (event: KeyboardEvent) => {
    if (event.key !== 'Tab') return;

    if (event.shiftKey) {
      // Shift + Tab
      if (document.activeElement === this.firstFocusable) {
        event.preventDefault();
        this.lastFocusable?.focus();
      }
    } else {
      // Tab
      if (document.activeElement === this.lastFocusable) {
        event.preventDefault();
        this.firstFocusable?.focus();
      }
    }
  };
}

// Screen reader announcements
export const announceToScreenReader = (message: string, priority: 'polite' | 'assertive' = 'polite') => {
  const announcement = document.createElement('div');
  announcement.setAttribute('aria-live', priority);
  announcement.setAttribute('aria-atomic', 'true');
  announcement.className = 'sr-only';
  
  document.body.appendChild(announcement);
  
  // Small delay to ensure screen readers pick up the content
  setTimeout(() => {
    announcement.textContent = message;
  }, 100);
  
  // Clean up after announcement
  setTimeout(() => {
    document.body.removeChild(announcement);
  }, 3000);
};

// Keyboard navigation helpers
export const handleEscapeKey = (callback: () => void) => {
  return (event: KeyboardEvent) => {
    if (event.key === 'Escape') {
      callback();
    }
  };
};

export const handleEnterOrSpace = (callback: () => void) => {
  return (event: KeyboardEvent) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      callback();
    }
  };
};

// ARIA attributes helpers
export const ariaHelpers = {
  expanded: (isExpanded: boolean) => ({
    'aria-expanded': isExpanded.toString()
  }),
  
  selected: (isSelected: boolean) => ({
    'aria-selected': isSelected.toString()
  }),
  
  pressed: (isPressed: boolean) => ({
    'aria-pressed': isPressed.toString()
  }),
  
  hidden: (isHidden: boolean) => ({
    'aria-hidden': isHidden.toString()
  }),

  labelledby: (id: string) => ({
    'aria-labelledby': id
  }),

  describedby: (id: string) => ({
    'aria-describedby': id
  })
};

// Reduce motion detection
export const prefersReducedMotion = (): boolean => {
  if (typeof window === 'undefined') return false;
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
};

// High contrast detection  
export const prefersHighContrast = (): boolean => {
  if (typeof window === 'undefined') return false;
  return window.matchMedia('(prefers-contrast: high)').matches;
};

// Color scheme detection
export const getPreferredColorScheme = (): 'light' | 'dark' => {
  if (typeof window === 'undefined') return 'light';
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
};